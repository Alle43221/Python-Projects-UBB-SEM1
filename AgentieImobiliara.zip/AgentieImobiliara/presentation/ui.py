from exceptions.repo_error import RepoError
from exceptions.ui_error import UIError


class UI:
    def __init__(self, service_locuinta):
        self.__service = service_locuinta
        self.__comenzi = {
            "filtrare_buget": self.__filtrare_buget,
            "inchiriere": self.__inchiriere
        }

    def __inchiriere(self, params):
        if len(params) != 1:
            raise UIError("Numar invalid de argumente!")
        try:
            id1 = int(params[0])
            chirie = self.__service.inchiriere(id1)
            if chirie is None:
                print("No matching object found!")
            else:
                mnv=chirie.get_pret()+chirie.get_garantie()+chirie.get_pret()/2
                print(str(chirie)+" "+str(mnv))
        except:
            raise UIError("valoare numerica invalida!")

    def __filtrare_buget(self, params):
        if len(params) != 2:
            raise UIError("Numar invalid de argumente!")
        try:
            chirie = int(params[0])
            oras = params[1]
            list = self.__service.filtrare_dupa_oras_chirie(oras, chirie)
            if len(list) == 0:
                print("No matching objects found!")
            else:
                for i in list:
                    print(i)
        except:
            raise UIError("valoare numerica invalida!")

    def run(self):
        while True:
            cmd = input(">>>")
            cmd = cmd.strip()
            if cmd == "exit":
                return
            parts = cmd.split("/")
            name = parts[0]
            params = parts[1:]
            if name in self.__comenzi:
                try:
                    self.__comenzi[name](params)
                except RepoError as error:
                    print(f"repo error: {error}")
                except UIError as error:
                    print(f"ui error: {error}")
                except Exception as error:
                    print(error)
            else:
                print("Comanda invalida!")
