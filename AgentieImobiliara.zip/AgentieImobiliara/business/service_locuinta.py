class ServiceLocuinta():
    def __init__(self, RepoLocuinta):
        self.__repo = RepoLocuinta

    def filtrare_dupa_oras_chirie(self, oras, chirie):
        lista = []
        lista1 = self.__repo.get_all()
        for i in lista1:
            if i.get_oras() == oras and i.get_pret() <= chirie:
                lista.append(i)
        return lista

    def inchiriere(self, id1):
        locuinta = self.__repo.search(id1)
        self.__repo.delete(id1)
        return locuinta
