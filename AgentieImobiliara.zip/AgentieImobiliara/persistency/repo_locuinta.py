from domain.domain_locuinta import Locuinta
from exceptions.repo_error import RepoError


class RepoLocuinta:
    def __init__(self):
        self._lista_locuinte = []

    def get_all(self):
        return self._lista_locuinte

    def delete(self, id1):
        if id1<0:
            raise RepoError("id invalid")
        for i in self._lista_locuinte:
            if i.get_id_locuinta()==id1:
                self._lista_locuinte.remove(i)

    def search(self, id1):
        if id1<0:
            raise RepoError("id invalid")
        for i in self._lista_locuinte:
            if i.get_id_locuinta()==id1:
                return i

class RepoFileLocuinta(RepoLocuinta):
    def __init__(self, path):
        super().__init__()
        self.__path = path

    def read_all_from_file(self):
        self._lista_locuinte.clear()
        with open(self.__path, "r") as f:
            line = f.readlines()
            for lin in line:
                if lin != '':
                    parts = lin.split(",")
                    id1 = int(parts[0])
                    adresa = parts[1]
                    oras = parts[2]
                    pret = int(parts[3])
                    garantie = int(parts[4])
                    locuinta = Locuinta(id1, adresa, oras, pret, garantie)
                    self._lista_locuinte.append(locuinta)

    def write_all_to_file(self):
        with open(self.__path, "w") as f:
            for i in self._lista_locuinte:
                f.write(repr(i)+'\n')

    def search(self, id1):
        self.read_all_from_file()
        return RepoLocuinta.search(self, id1)

    def delete(self, id1):
        self.read_all_from_file()
        RepoLocuinta.delete(self, id1)
        self.write_all_to_file()

    def get_all(self):
        self.read_all_from_file()
        return RepoLocuinta.get_all(self)
