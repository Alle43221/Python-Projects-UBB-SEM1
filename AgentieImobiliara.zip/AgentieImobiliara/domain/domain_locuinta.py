class Locuinta:
    def __init__(self, id_locuinta, adresa, oras, pret, garantie):
        self.__id_locuinta = id_locuinta
        self.__adresa = adresa
        self.__oras = oras
        self.__pret = pret
        self.__garantie = garantie

    def get_id_locuinta(self):
        return self.__id_locuinta

    def get_adresa(self):
        return self.__adresa

    def get_oras(self):
        return self.__oras

    def get_pret(self):
        return self.__pret

    def get_garantie(self):
        return self.__garantie

    def __eq__(self, other):
        return self.__id_locuinta == other.__id_locuinta

    def __str__(self):
        return f"{self.__id_locuinta} {self.__adresa} din {self.__oras} la {self.__pret}/luna"

    def __repr__(self):
        return f"{self.__id_locuinta},{self.__adresa},{self.__oras},{self.__pret},{self.__garantie}"
