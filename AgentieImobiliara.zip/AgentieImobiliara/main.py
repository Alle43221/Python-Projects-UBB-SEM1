from persistency.repo_locuinta import RepoFileLocuinta
from business.service_locuinta import ServiceLocuinta
from tests.test_locuinta import TestLocuinta
from presentation.ui import UI

tester=TestLocuinta()
tester.run_all_tests()

persistency=RepoFileLocuinta("./persistency/locuinte.txt")
business=ServiceLocuinta(persistency)

ui=UI(business)

ui.run()


