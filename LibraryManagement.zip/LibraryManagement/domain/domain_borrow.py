class Borrow:
    def __init__(self, id_book, id_client):
        '''
        :param id_book: integer >0
        :param id_client: integer >0
        :description: initializes a Borrow object
        :return: Borrow object
        '''
        self.__id_book = id_book
        self.__id_client = id_client
        self.__status = "active"

    def get_id_book(self):
        '''
        :description: getter for field id_book
        :return: integer
        :param: none
        '''
        return self.__id_book

    def get_status(self):
        '''
        :description: getter for field status
        :return: string
        :param: none
        '''
        return self.__status

    def get_id_client(self):
        '''
        :description: getter for field id_client
        :return: integer
        :param: none
        '''
        return self.__id_client

    def set_status(self, new_status):
        '''
            :description: setter for field status
            :return: none
            :param: string
        '''
        self.__status = new_status

    def __eq__(self, other):
        '''
           :description: overwritten equality operator
           :return: True or False
           :param: Borrow object
       '''
        return self.__id_book == other.__id_book and self.__status == 'active' and other.__status == 'active'

    def __str__(self):
        '''
           :description: overwritten print format
           :return: string
           :param: none
       '''
        return f"{self.__id_book} {self.__id_client} {self.__status}"
