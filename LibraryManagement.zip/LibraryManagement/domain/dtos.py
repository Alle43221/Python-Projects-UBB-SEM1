class ReportBook:
    def __init__(self, title, author, times, id_book):
        '''
        :description: initializes a new ReportBook object
        :param title: string
        :param author: string
        :param times: integer
        :param id_book: integer>0
        :return: none
        '''
        self.__id_book = id_book
        self.__title = title
        self.__author = author
        self.__times = times

    def get_times(self):
        '''
        :description: getter for field times
        :return: integer
        :param: none
        '''
        return self.__times

    def __str__(self):
        '''
           :description: overwritten print format
           :return: string
           :param: none
       '''
        return f"[{self.__id_book}] {self.__title} by {self.__author} -- {self.__times}"


class ReportClient:
    def __init__(self, name, id_client, books):
        self.__name = name
        self.__id_client = id_client
        self.__books = books

    def get_books(self):
        '''
        :description: getter for field books
        :return: integer
        :param: none
        '''
        return self.__books

    def get_name(self):
        '''
        :description: getter for field name
        :return: string
        :param: none
        '''
        return self.__name

    def __str__(self):
        '''
           :description: overwritten print format
           :return: string
           :param: none
       '''
        return f"[{self.__id_client}] {self.__name}  -- {self.__books}"
