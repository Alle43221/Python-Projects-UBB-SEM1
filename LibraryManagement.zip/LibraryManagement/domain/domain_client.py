class Client:
    def __init__(self, id_client, name, cnp):
        '''
        :description: initializes a new Client object
        :param id_client: integer >0
        :param name: string
        :param cnp: string
        :return: none
        '''
        self.__id_client = id_client
        self.__name = name
        self.__cnp = cnp

    def get_id_client(self):
        '''
        :description: getter for field id_client
        :return: integer
        :param: none
        '''
        return self.__id_client

    def get_name(self):
        '''
        :description: getter for field name
        :return: string
        :param: none
        '''
        return self.__name

    def get_cnp(self):
        '''
        :description: getter for field cnp
        :return: string
        :param: none
        '''
        return self.__cnp

    def set_id_client(self, id_client):
        '''
            :description: setter for field id_client
            :return: none
            :param: integer >0
        '''
        self.__id_client = id_client

    def set_cnp(self, cnp):
        '''
            :description: setter for field cnp
            :return: none
            :param: string
        '''
        self.__cnp = cnp

    def set_name(self, name):
        '''
            :description: setter for field name
            :return: none
            :param: string
        '''
        self.__name = name

    def __eq__(self, other):
        '''
           :description: overwritten equality operator
           :return: True or False
           :param: Client object
       '''
        return self.__id_client == other.__id_client

    def __str__(self):
        '''
           :description: overwritten print format
           :return: string
           :param: none
       '''
        return f"{self.__id_client} {self.__name} {self.__cnp}"
