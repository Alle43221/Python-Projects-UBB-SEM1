class Book:
    def __init__(self, id_book, title, author, description):
        '''
        :param id_book: integer >0
        :param title: string
        :param author: string
        :param description: string
        :description: initializes a Book object
        :return: Book object
        '''
        self.__id_book = id_book
        self.__title = title
        self.__author = author
        self.__description = description

    def get_id_book(self):
        '''
        :description: getter for field id_book
        :return: integer
        :param: none
        '''
        return self.__id_book

    def get_title(self):
        '''
        :description: getter for field title
        :return: string
        :param: none
        '''
        return self.__title

    def get_author(self):
        '''
            :description: getter for field author
            :return: string
            :param: none
        '''
        return self.__author

    def get_description(self):
        '''
        :description: getter for field description
        :return: string
        :param: none
        '''
        return self.__description

    def set_id_book(self, id_book):
        '''
            :description: setter for field id_book
            :return: none
            :param: integer >0
        '''
        self.__id_book = id_book

    def set_title(self, title):
        '''
            :description: setter for field title
            :return: none
            :param: string
        '''
        self.__title = title

    def set_author(self, author):
        '''
            :description: setter for field author
            :return: none
            :param: string
        '''
        self.__author = author

    def set_description(self, description):
        '''
            :description: setter for field description
            :return: none
            :param: string
        '''
        self.__description = description

    def __eq__(self, other):
        '''
           :description: overwritten equality operator
           :return: True or False
           :param: Book object
       '''
        return self.__id_book == other.__id_book

    def __str__(self):
        '''
           :description: overwritten print format
           :return: string
           :param: none
       '''
        return f"{self.__id_book} {self.__title} by {self.__author} {self.__description}"
