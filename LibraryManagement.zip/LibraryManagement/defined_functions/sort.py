class Sort:
    def bubble_sort(self, list1, reversed=False, function=None, key=None):
        '''
        :param list1: list to be sorted
        :param reversed: true/false
        :param function: lambda/user defined function for comparison
        :param key: field to be sorted by
        :return: none
        '''
        if key is not None and function is not None:
            raise Exception("Cannot have both fields function and key filled!")
        if key is None and function is None:
            function = (lambda x, y: x < y)
            n = len(list1)
            for i in range(0, n):
                swap = 0
                for j in range(0, n - i - 1):
                    if reversed:
                        if function(list1[j], list1[j + 1]):
                            list1[j], list1[j + 1] = list1[j + 1], list1[j]
                            swap = 1
                    else:
                        if not function(list1[j], list1[j + 1]):
                            list1[j], list1[j + 1] = list1[j + 1], list1[j]
                            swap = 1

                if swap == 0:
                    break
            return list1
        if key is None:
            n = len(list1)
            for i in range(0, n):
                swap = 0
                for j in range(0, n - i - 1):
                    if reversed:
                        if function(list1[j], list1[j + 1]):
                            list1[j], list1[j + 1] = list1[j + 1], list1[j]
                            swap = 1
                    else:
                        if not function(list1[j], list1[j + 1]):
                            list1[j], list1[j + 1] = list1[j + 1], list1[j]
                            swap = 1

                if swap == 0:
                    break
            return list1
        if function is None:
            n = len(list1)
            for i in range(0, n):
                swap = 0
                for j in range(0, n - i - 1):
                    if reversed:
                        if key(list1[j])< key(list1[j + 1]):
                            list1[j], list1[j + 1] = list1[j + 1], list1[j]
                            swap = 1
                    else:
                        if key(list1[j])> key( list1[j + 1]):
                            list1[j], list1[j + 1] = list1[j + 1], list1[j]
                            swap = 1

                if swap == 0:
                    break
            return list1

    def shell_sort(self, list1, reversed=False, function=None, key=None):
        '''
        :param list1: list to be sorted
        :param reversed: true/false
        :param function: lambda/user defined function for comparison
        :param key: field to be sorted by
        :return: none
        '''
        if key is not None and function is not None:
            raise Exception("Cannot have both fields function and key filled!")
        if key is None and function is None:
            function = (lambda x, y: x < y)
            n = len(list1)
            gap = int((n + 1) / 2)
            while gap > 0:
                i = gap
                while i < n:
                    copy = list1[i]
                    j = i
                    if reversed:
                        while j >= gap and not function(list1[j], list1[j - gap]):
                            list1[j] = list1[j - gap]
                            j -= gap
                    else:
                        while j >= gap and function(list1[j], list1[j - gap]):
                            list1[j] = list1[j - gap]
                            j -= gap
                    list1[j] = copy
                    i += 1
                if gap != 1:
                    gap = int((gap + 1) / 2)
                else:
                    gap -= 1
            return list1
        if key is None:
            n = len(list1)
            gap = int((n + 1) / 2)
            while gap > 0:
                i = gap
                while i < n:
                    copy = list1[i]
                    j = i
                    if reversed:
                        while j >= gap and not function(list1[j], list1[j - gap]):
                            list1[j] = list1[j - gap]
                            j -= gap
                    else:
                        while j >= gap and function(list1[j], list1[j - gap]):
                            list1[j] = list1[j - gap]
                            j -= gap
                    list1[j] = copy
                    i += 1
                if gap != 1:
                    gap = int((gap + 1) / 2)
                else:
                    gap -= 1
            return list1
        if function is None:
            n = len(list1)
            gap = int((n + 1) / 2)
            while gap > 0:
                i = gap
                while i < n:
                    copy = list1[i]
                    j = i
                    if reversed:
                        while j >= gap and key(list1[j])> key(list1[j - gap]):
                            list1[j] = list1[j - gap]
                            j -= gap
                    else:
                        while j >= gap and key(list1[j])< key(list1[j - gap]):
                            list1[j] = list1[j - gap]
                            j -= gap
                    list1[j] = copy
                    i += 1
                if gap != 1:
                    gap = int((gap + 1) / 2)
                else:
                    gap -= 1
            return list1
