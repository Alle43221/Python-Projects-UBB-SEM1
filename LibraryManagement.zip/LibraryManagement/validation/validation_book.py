from exceptions.except_validate import ValidationError


class ValidateBook:
    def validate_book(self, new_book):
        '''
        :description: validator for Book object
        :param new_book: Book object
        :return: none
        :exception: raises a ValidationError with a string of found problems
        '''
        errors = ""

        if new_book.get_id_book() <= 0:
            errors += "Invalid ID! "
        else:
            try:
                aux = int(new_book.get_id_book())
            except:
                errors += "Invalid ID! "

        if new_book.get_author() == "":
            errors += "Invalid author! "
        else:
            for c in new_book.get_author():
                if c.isnumeric():
                    errors += "Invalid author! "
                    break

        if new_book.get_description() == "":
            errors += "Invalid description! "

        if new_book.get_title() == "":
            errors += "Invalid title! "

        if len(errors) > 0:
            raise ValidationError(errors)
