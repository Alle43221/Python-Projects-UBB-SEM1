from datetime import datetime

from exceptions.except_validate import ValidationError


class ValidateClient:

    def validate_cnp(self, new_client):
        '''
        :description: validator for CNP field of Client object
        :param new_client: Client object
        :return: True or False
        '''
        if len(new_client.get_cnp()) != 13:
            return 0

        for c in new_client.get_cnp():
            if c.isnumeric() == 0:
                return 0

        if int(new_client.get_cnp()[0]) == 3 or int(new_client.get_cnp()[0]) == 4:
            return 0

        county_code = int(new_client.get_cnp()[7:9])
        if county_code==50 or county_code>52 or county_code<=0:
            return 0

        personal_code = int(new_client.get_cnp()[9:12])
        if personal_code<=0:
            return 0

        date_format = '%y%m%d'
        try:
            datetime.strptime(new_client.get_cnp()[1:7], date_format)
            return 1
        except:
            return 0


    def validate_client(self, new_client):
        '''
            :description: validator for Client object
            :param new_client: Client object
            :return: none
            :exception: raises a ValidationError with a string of found problems
        '''
        errors = ""

        if new_client.get_id_client() <= 0:
            errors += "Invalid ID! "
        else:
            try:
                aux = int(new_client.get_id_client())
            except:
                errors += "Invalid ID! "

        if new_client.get_name() == "":
            errors += "Invalid name! "
        else:
            for c in new_client.get_name():
                if c.isnumeric():
                    errors += "Invalid name! "
                    break

        if self.validate_cnp(new_client) == 0:
            errors += "Invalid CNP! "

        if len(errors) > 0:
            raise ValidationError(errors)
