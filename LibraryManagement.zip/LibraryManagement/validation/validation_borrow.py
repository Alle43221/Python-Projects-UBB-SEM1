from exceptions.except_validate import ValidationError


class ValidateBorrow:
    def validate_borrow(self, new_borrow, list_books, list_clients):
        '''
        :description: validator for Borrow object
        :param new_borrow: Borrow object
        :param list_books: array of Book objects
        :param list_clients: array of Client objects
        :return: none
        :exception: raises a ValidationError with a string of found problems
        '''
        errors = ""
        ok = 0
        for i in list_books:
            if i.get_id_book() == new_borrow.get_id_book():
                ok += 1
                continue
        for i in list_clients:
            if i.get_id_client() == new_borrow.get_id_client():
                ok += 1
                continue
        if ok != 2:
            errors += "Non-existing book or client id!"

        if len(errors) > 0:
            raise ValidationError(errors)
