from domain.domain_book import Book
from domain.domain_borrow import Borrow
from domain.domain_client import Client
from repository.repo_borrow import FileRepoBorrow
from services.services_borrow import BorrowService


class TestBorrow:
    def __init__(self, validation_borrow, repo_borrows, service_borrows, service_book, service_client):
        '''
        :description: initializes a new instance of TestBorrow class
        :param validation_borrow: instance of ValidateBorrow class
        :param repo_borrows: instance of BorrowRepository class
        :param service_borrows: instance of BorrowService class
        :return: none
        '''
        self.__validation_borrow = validation_borrow
        self.__service_borrow = service_borrows
        self.__repo_borrow = repo_borrows
        self.__service_book = service_book
        self.__service_client = service_client

    def __test_validate_borrow(self):
        '''
        :description: function to test the ValidateBorrow class
        :return: none
        :param: none
        '''
        books = []
        clients = []
        id_book = 12
        id_client = 14
        borrow = Borrow(id_book, id_client)
        try:
            self.__validation_borrow.validate_borrow(borrow, books, clients)
            assert False
        except Exception as ex:
            assert (str(ex) == "Non-existing book or client id!")
        title = "Cei-trei-purcelusi"
        author = "Povesti-clasice"
        description = "Povesti-pentru-copii"
        book = Book(id_book, title, author, description)
        books.append(book)
        try:
            self.__validation_borrow.validate_borrow(borrow, books, clients)
            assert False
        except Exception as ex:
            assert (str(ex) == "Non-existing book or client id!")
        name = "Ion-Bravu"
        cnp = "6040923303929"
        client = Client(id_client, name, cnp)
        clients.append(client)
        self.__validation_borrow.validate_borrow(borrow, books, clients)

    def __test_create_borrow(self):
        '''
        :description: function to test the Borrow class methods
        :return:none
        :param: none
        '''
        id_book = 12
        id_client = 14
        borrow1 = Borrow(id_book, id_client)
        id_client1 = 15
        borrow2 = Borrow(id_book, id_client1)
        assert borrow1.get_id_book() == id_book
        assert borrow1.get_status() == borrow2.get_status()
        assert borrow1.get_id_client() == id_client
        assert borrow2 == borrow1

    def __test_repo_borrow(self):
        '''
        :description: function to test the functionalities of BorowRepository
        :return:none
        :param: none
        '''
        id_book = 12
        id_client = 14
        borrow = Borrow(id_book, id_client)
        assert len(self.__repo_borrow.get_all_borrow_repo()) == self.__repo_borrow.get_size()
        self.__repo_borrow.add_borrow_repo(borrow)
        assert len(self.__repo_borrow.get_all_borrow_repo()) == 1
        assert len(self.__repo_borrow.get_all_borrow_repo()) == self.__repo_borrow.get_size()
        try:
            self.__repo_borrow.add_borrow(borrow)
            assert False
        except:
            assert True
        assert self.__repo_borrow.search_borrow(borrow) == borrow

        self.__repo_borrow.modify_borrow(borrow)
        try:
            self.__repo_borrow.search_book(borrow)
            assert False
        except:
            assert True
        self.__repo_borrow.get_all_borrow_repo().clear()

    def __test_service_borrow(self):
        '''
        :description: function to test functionalities of BookService class
        :return: none
        :param: none
        '''
        assert len(self.__service_borrow.get_all_borrows()) == 0
        id_book = 13
        title = "Comoara-din-insula"
        author = "Robert-Stevenson"
        description = "pirates"
        self.__service_book.add_book(id_book, title, author, description)

        id_book1 = 19
        title1 = "Comoara-din-insula2"
        author = "Robert-Stevenson"
        description = "pirates"
        self.__service_book.add_book(id_book1, title1, author, description)

        id_book2 = 20
        title2 = "Comoara-din-insula3"
        author = "Robert-Stevenson"
        description = "pirates"
        self.__service_book.add_book(id_book2, title2, author, description)

        id_client = 14
        name = "Anne-Zane"
        cnp = "6040923303929"
        self.__service_client.add_client(id_client, name, cnp)

        borrow = Borrow(id_book, id_client)
        self.__service_borrow.add_borrow(id_book, id_client)
        assert len(self.__service_borrow.get_all_borrows()) == 1
        assert self.__service_borrow.get_all_borrows()[-1] == borrow
        self.__service_borrow.delete_borrow(id_book)
        assert len(self.__service_borrow.get_all_borrows()) == 1
        assert self.__service_borrow.get_all_borrows()[-1] != borrow

        id_client1 = 15
        name1 = "Anne-Smith"
        cnp = "6040923303929"
        self.__service_client.add_client(id_client1, name1, cnp)
        self.__service_borrow.add_borrow(id_book1, id_client1)

        self.__service_borrow.add_borrow(id_book, id_client)

        assert self.__service_borrow.report_popular_books()[0].get_times() ==2
        assert len(self.__service_borrow.report_popular_books()) ==2

        self.__service_borrow.add_borrow(id_book2, id_client)

        assert len(self.__service_borrow.report_active_clients_books())==2
        assert self.__service_borrow.report_active_clients_books()[0].get_name()==name
        assert self.__service_borrow.report_active_clients_books()[0].get_books() == 2
        assert self.__service_borrow.report_active_clients_books()[1].get_name()==name1
        assert self.__service_borrow.report_active_clients_books()[1].get_books() == 1

        assert len(self.__service_borrow.report_active_clients_name()) == 2
        assert self.__service_borrow.report_active_clients_name()[0].get_name() == name1
        assert self.__service_borrow.report_active_clients_name()[0].get_books() == 1
        assert self.__service_borrow.report_active_clients_name()[1].get_name() == name
        assert self.__service_borrow.report_active_clients_name()[1].get_books() == 2

        self.__service_borrow.delete_borrow(id_book1)

        assert len(self.__service_borrow.report_top_clients()) == 2
        assert self.__service_borrow.report_top_clients()[0].get_name() == name
        assert self.__service_borrow.report_top_clients()[0].get_books() == 3
        assert self.__service_borrow.report_top_clients()[1].get_name() == name1
        assert self.__service_borrow.report_top_clients()[1].get_books() == 1

    def __test_file_function(self):
        with open("./tests/borrows_file.txt", "w") as f:
            f.close()
        repo_file = FileRepoBorrow("./tests/borrows_file.txt")
        repo_clients = FileRepoBorrow("./tests/clients_file.txt")
        repo_books = FileRepoBorrow("./tests/books_file.txt")
        service = BorrowService(repo_file, self.__validation_borrow, repo_clients, repo_books)
        id_client = 17
        id_book=44
        assert len(service.get_all_borrows()) == 0
        service.add_borrow(id_book, id_client)
        assert len(service.get_all_borrows()) == 1

    def run_all_tests(self):
        self.__test_validate_borrow()
        self.__test_create_borrow()
        self.__test_repo_borrow()
        self.__test_service_borrow()
