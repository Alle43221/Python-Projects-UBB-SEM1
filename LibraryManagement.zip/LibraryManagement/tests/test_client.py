from domain.domain_client import Client
from repository.repo_client import FileRepoClient
from services.services_client import ClientService


class TestClient:
    def __init__(self, validation_client, repo_client, service_client):
        '''
        :description: initializes a new instance of TestBook class
        :param validation_client: instance of ValidateClient class
        :param repo_client: instance of ClientRepository class
        :param service_client: instance of ClientService class
        :return: none
        '''
        self.__validation_client = validation_client
        self.__service_client = service_client
        self.__repo_client = repo_client

    def __test_validate_client(self):
        '''
        :description: function to test the ValidateClient class
        :return: none
        :param: none
        '''
        id_client = -12
        name = ""
        cnp = "123"
        client = Client(id_client, name, cnp)
        try:
            self.__validation_client.validate_client(client)
            assert False
        except Exception as ex:
            assert (str(ex) == "Invalid ID! Invalid name! Invalid CNP! ")
        id_client = 12
        name = "Ion-Bravu"
        cnp = "6040923303929"
        client = Client(id_client, name, cnp)
        self.__validation_client.validate_client(client)

    def __test_create_client(self):
        '''
        :description: function to test the Client class methods
        :return:none
        :param: none
        '''
        id_client = 12
        name = "John-Smith"
        cnp = "6040923303929"
        client = Client(id_client, name, cnp)
        other_name = "Jane-Smith"
        other_cnp = "6050923303929"
        other_client = Client(id_client, other_name, other_cnp)
        assert client.get_id_client() == id_client
        assert client.get_name() == name
        assert client.get_cnp() == cnp
        assert client == other_client

    def __test_repo_client(self):
        '''
        :description: function to test the functionalities of ClientRepository
        :return: none
        :param: none
        '''
        id_client = 12
        name = "John-Smith"
        cnp = "6040923303929"
        assert len(self.__repo_client.get_all_clients()) == self.__repo_client.get_size()
        client = Client(id_client, name, cnp)
        self.__repo_client.add_client(client)
        assert len(self.__repo_client.get_all_clients()) == 1
        assert len(self.__repo_client.get_all_clients()) == self.__repo_client.get_size()
        try:
            self.__repo_client.add_client(client)
            assert False
        except:
            assert True
        assert self.__repo_client.search_client(client) == client

        new_name = "Robins-Crusoe"
        client.set_name(new_name)
        self.__repo_client.modify_client(client)
        assert self.__repo_client.search_client(client).get_name() == new_name

        self.__repo_client.delete_client(client)
        try:
            self.__repo_client.search_client(client)
            assert False
        except:
            assert True

    def __test_service_client(self):
        '''
        :description: function to test functionalities of ClientService class
        :return: none
        :param: none
        '''
        assert len(self.__service_client.get_all_clients()) == 0
        id_client = 12
        name = "John-Smith"
        cnp = "6040923303929"
        self.__service_client.add_client(id_client, name, cnp)
        found_client = self.__service_client.search_client(id_client)
        client = Client(id_client, name, cnp)
        assert found_client.get_id_client() == id_client
        assert found_client.get_name() == name
        assert found_client.get_cnp() == cnp
        assert client == found_client
        name2 = "John-Watson"
        self.__service_client.modify_client(id_client, name2, cnp)
        found_book = self.__service_client.search_client(id_client)
        assert found_book.get_name() == name2

        self.__service_client.delete_client(id_client)
        try:
            self.__service_client.search_client(id_client)
            assert False
        except:
            assert True

    def __test_file_function(self):
        with open("./tests/clients_file.txt", "w") as f:
            f.close()
        repo_file = FileRepoClient("./tests/clients_file.txt")
        service = ClientService(repo_file, self.__validation_client)
        id_client = 17
        name = "John-Smith"
        cnp = "6040923303929"
        assert len(service.get_all_clients()) == 0
        service.add_client(id_client, name, cnp)
        assert len(service.get_all_clients()) == 1

    def run_all_tests(self):
        self.__test_validate_client()
        self.__test_create_client()
        self.__test_repo_client()
        self.__test_service_client()
        self.__test_file_function()
