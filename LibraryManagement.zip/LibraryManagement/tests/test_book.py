from domain.domain_book import Book
from defined_functions.sort import Sort
from functools import cmp_to_key

from repository.repo_book import FileRepoBooks
from services.services_book import BookService


class TestBook:
    def __init__(self, validation_book, repo_books, service_books):
        '''
        :description: initializes a new instance of TestBook class
        :param validation_book: instance of ValidateBook class
        :param repo_books: instance of BookRepository class
        :param service_books: instance of BookService class
        :return: none
        '''
        self.__validation_book = validation_book
        self.__service_books = service_books
        self.__repo_books = repo_books

    def __test_validate_book(self):
        '''
        :description: function to test the ValidateBook class
        :return: none
        :param: none
        '''
        id_book = -1
        title = ""
        author = ""
        description = ""
        book = Book(id_book, title, author, description)
        try:
            self.__validation_book.validate_book(book)
            assert False
        except Exception as ex:
            assert (str(ex) == "Invalid ID! Invalid author! Invalid description! Invalid title! ")

        id_book = 12
        title = "Cei-trei-purcelusi"
        author = "Povesti-clasice"
        description = "Povesti-pentru-copii"
        book = Book(id_book, title, author, description)
        self.__validation_book.validate_book(book)

    def __test_create_book(self):
        '''
        :description: function to test the Book class methods
        :return:none
        :param: none
        '''
        id_book = 12
        title = "Mowgli"
        author = "James-Brown"
        description = "short-story"
        book1 = Book(id_book, title, author, description)
        title1 = "Space Oddysey"
        author1 = "James-Red"
        description1 = "long-story"
        book2 = Book(id_book, title1, author1, description1)
        assert book1.get_id_book() == id_book
        assert book1.get_title() == title
        assert book1.get_author() == author
        assert book1.get_description() == description
        assert book1 == book2

    def __test_repo_book(self):
        '''
        :description: function to test the functionalities of BookRepository
        :return:none
        :param: none
        '''
        id_book = 12
        title = "Mowgli"
        author = "James-Brown"
        description = "short-story"
        assert len(self.__repo_books.get_all_books_repo()) == self.__repo_books.get_size()
        book = Book(id_book, title, author, description)
        self.__repo_books.add_book(book)
        assert len(self.__repo_books.get_all_books_repo()) == 1
        assert len(self.__repo_books.get_all_books_repo()) == self.__repo_books.get_size()
        try:
            self.__repo_books.add_book(book)
            assert False
        except:
            assert True
        assert self.__repo_books.search_book(book) == book

        new_title = "Mowgli2"
        book.set_title(new_title)
        self.__repo_books.modify_book(book)
        assert self.__repo_books.search_book(book).get_title() == new_title

        new_title = "Mowgli3"
        book.set_title(new_title)
        self.__repo_books.modify_book1(book, 0)
        assert self.__repo_books.search_book1(book, 0).get_title() == new_title

        self.__repo_books.delete_book(book)
        try:
            self.__repo_books.search_book(book)
            assert False
        except:
            assert True

    def __test_service_book(self):
        '''
        :description: function to test functionalities of BookService class
        :return: none
        :param: none
        '''
        assert len(self.__service_books.get_all_books()) == 0
        self.__service_books.generate_books(5)
        assert len(self.__service_books.get_all_books()) == 5
        id_book = 12
        title = "Mowgli"
        author = "James-Brown"
        description = "short-story"
        self.__service_books.add_book(id_book, title, author, description)
        found_book = self.__service_books.search_book(id_book)
        book = Book(id_book, title, author, description)
        assert found_book.get_id_book() == id_book
        assert found_book.get_title() == title
        assert found_book.get_author() == author
        assert found_book.get_description() == description
        assert book == found_book
        title1 = "Mowgli2"
        self.__service_books.modify_book(id_book, title1, author, description)
        found_book = self.__service_books.search_book(id_book)
        assert found_book.get_title() == title1

        self.__service_books.delete_book(id_book)
        try:
            self.__service_books.search_book(id_book)
            assert False
        except:
            assert True

    def __test_sort(self):
        '''
        :description: function to test the user-implemented sort functions
        :return: none
        :param: none
        '''
        list1=self.__service_books.get_all_books()
        lis2=self.__service_books.get_all_books()
        lis2.sort( key=lambda x:x.get_title())
        sort=Sort()
        sort.bubble_sort(list1, key=lambda x:x.get_title())
        assert list1==lis2

        lis2.sort(key=lambda x: x.get_title(), reverse=True)
        sort = Sort()
        sort.bubble_sort(list1, key=lambda x: x.get_title(), reversed=True)
        assert list1 == lis2

        fun=lambda a,b:1 if a.get_title()<b.get_title() else 0
        key=cmp_to_key(fun)
        lis2.sort(key=key, reverse=True)
        sort = Sort()
        sort.bubble_sort(list1,reversed=True, function=lambda x, y: x.get_title()<y.get_title())
        assert list1 == lis2

        fun = lambda a, b: 1 if a.get_title() < b.get_title() else 0
        key = cmp_to_key(fun)
        lis2.sort(key=key)
        sort = Sort()
        sort.bubble_sort(list1, function=lambda x, y: x.get_title() < y.get_title())
        assert list1 == lis2

        try:
            sort.bubble_sort(list1, function=lambda x, y: x.get_title() < y.get_title(), key=lambda x:x.get_title())
            assert False
        except:
            assert True

        list1 = self.__service_books.get_all_books()
        lis2 = self.__service_books.get_all_books()
        lis2.sort(key=lambda x: x.get_title())
        sort = Sort()
        sort.shell_sort(list1, key=lambda x: x.get_title())
        assert list1 == lis2

        lis2.sort(key=lambda x: x.get_title(), reverse=True)
        sort = Sort()
        sort.shell_sort(list1, key=lambda x: x.get_title(), reversed=True)
        assert list1 == lis2

        fun = lambda a, b: 1 if a.get_title() < b.get_title() else 0
        key = cmp_to_key(fun)
        lis2.sort(key=key, reverse=True)
        sort = Sort()
        sort.shell_sort(list1, reversed=True, function=lambda x, y: x.get_title() < y.get_title())
        assert list1 == lis2

        fun = lambda a, b: 1 if a.get_title() < b.get_title() else 0
        key = cmp_to_key(fun)
        lis2.sort(key=key)
        sort = Sort()
        sort.shell_sort(list1, function=lambda x, y: x.get_title() < y.get_title())
        assert list1 == lis2

        try:
            sort.shell_sort(list1, function=lambda x, y: x.get_title() < y.get_title(), key=lambda x: x.get_title())
            assert False
        except:
            assert True

    def __test_file_functions(self):
        '''
        description: function to test interaction with files
        :return: none
        :param: none
        '''
        with open("./tests/books_file.txt", "w") as f:
            f.close()
        assert len(self.__service_books.get_all_books()) == 5
        repo_file=FileRepoBooks("./tests/books_file.txt")
        service=BookService(repo_file, self.__validation_book)
        id_book = 44
        title = "Mowgli"
        author = "James-Brown"
        description = "short-story"
        assert len(service.get_all_books()) == 0
        service.add_book(id_book, title, author, description)
        assert len(service.get_all_books())==1


    def run_all_tests(self):
        '''
        :description: master test function for all functionalities implemented
        :return: none
        :param: none
        '''
        self.__test_validate_book()
        self.__test_create_book()
        self.__test_repo_book()
        self.__test_service_book()
        self.__test_sort()
        self.__test_file_functions()
