from exceptions.except_repo import RepoError
from exceptions.except_ui import UIError
from exceptions.except_validate import ValidationError


class UI:
    def __init__(self, services_books, services_client, services_borrow):
        '''
        :param services_books: instance of BookService class
        :param services_client: instance of ClientService class
        :param services_borrow: instance of BorrowService class
        :return: UI object
        :description: initializes a new instance of UI
        '''
        self.__services_books = services_books
        self.__services_client = services_client
        self.__services_borrow = services_borrow
        self.__commands = {
            "add_book": self.__ui_add_book,
            "print_books": self.__ui_print_books,
            "add_client": self.__ui_add_client,
            "print_clients": self.__ui_print_clients,
            "delete_client": self.__ui_delete_client,
            "delete_book": self.__ui_delete_book,
            "modify_book": self.__ui_modify_book,
            "modify_client": self.__ui_modify_client,
            "search_book": self.__ui_search_book,
            "search_client": self.__ui_search_client,
            "borrow_book": self.__ui_borrow_book,
            "return_book": self.__ui_return_book,
            "generate_books": self.__ui_generate_books,
            "print_borrows": self.__ui_print_borrows,

            "report_popular_books": self.__ui_report_popular_books,
            "report_top_clients": self.__ui_report_top_clients,
            "report_active_clients_by_name": self.__ui_report_active_clients_by_name,
            "report_active_clients_by_books": self.__ui_report_active_clients_by_books,
        }

    def __ui_generate_books(self, params):
        '''
        :description: generates a given number of Book objects
        :param params: array of parameters [integer]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter!"
        '''
        if len(params) != 1:
            print("Invalid number of parameters! Expected 1")
            return
        try:
            number = int(params[0])
            if number < 0:
                print("Invalid value for parameter! Expected a positive integer.")
                return
            self.__services_books.generate_books(number)
            print("Entries generated with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter!")

    def __ui_print_borrows(self, params):
        '''
               :description: prints the current borrow list
               :param params: array of parameters []
               :return: none
               :exception: invalid number of parameters
                           empty borrow list
        '''
        if len(params) > 0:
            print("Invalid number of parameters! Expected none")
            return
        borrows = self.__services_borrow.get_all_borrows()
        if len(borrows) == 0:
            print("No available borrows!")
        else:
            for borrow in borrows:
                print(borrow)

    def __ui_report_active_clients_by_books(self, params):
        '''
        :description: reports top 10 clients with currently borrowed books, ordered by the number of them borrowed
        :param params: array of parameters
        :return: none
        '''
        if len(params) != 0:
            print("Invalid number of parameters! Expected none")
            return
        clients = self.__services_borrow.report_active_clients_books()
        if len(clients) == 0:
            print("No available report")
        for client in clients:
            print(client)

    def __ui_report_active_clients_by_name(self, params):
        '''
        :description: reports top 10 clients with currently borrowed books, ordered by their name
        :param params: array of parameters
        :return: none
        '''
        if len(params) != 0:
            print("Invalid number of parameters! Expected none")
            return
        clients = self.__services_borrow.report_active_clients_name()
        if len(clients) == 0:
            print("No available report")
        for client in clients:
            print(client)

    def __ui_report_top_clients(self, params):
        if len(params) != 0:
            print("Invalid number of parameters! Expected none")
            return
        clients = self.__services_borrow.report_top_clients()
        if len(clients) == 0:
            print("No available clients")
        else:
            for client in clients:
                print(client)

    def __ui_report_popular_books(self, params):
        '''
        :description: reports top 5 most popular books
        :param params: array of parameters
        :return: none
        '''
        if len(params) != 0:
            print("Invalid number of parameters! Expected none")
            return
        books = self.__services_borrow.report_popular_books()
        if len(books) == 0:
            print("No available books")
        else:
            for book in books:
                print(book)

    def __ui_return_book(self, params):
        '''
        :description: returns a book
        :param params: array of parameters [integer]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_book!"
        '''
        if len(params) != 1:
            print("Invalid number of parameters! Expected 1")
            return
        try:
            id_book = int(params[0])
            self.__services_borrow.delete_borrow(id_book)
            print("Book returned with success!")
        except ValueError:
            print("Non-numeric value for parameter id_book!")

    def __ui_borrow_book(self, params):
        '''
        :description: borrows a book
        :param params: array of parameters [integer, integer]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_book or id_client!"
        '''
        if len(params) != 2:
            print("Invalid number of parameters! Expected 2")
            return
        try:
            id_book = int(params[0])
            id_client = int(params[1])
            self.__services_borrow.add_borrow(id_book, id_client)
            print("Book borrowed with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter id_book or id_client!")

    def __ui_search_client(self, params):
        '''
        :description: searches and prints client with given id
        :param params: array of parameters [integer]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_client!"
        '''
        if len(params) != 1:
            print("Invalid number of parameters! Expected 1")
            return
        try:
            id_client = int(params[0])
            client = self.__services_client.search_client(id_client)
            print(client)
        except ValueError:
            raise UIError("Non-numeric value for parameter id_client!")

    def __ui_search_book(self, params):
        '''
        :description: searches and prints book with given id
        :param params: array of parameters [integer]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_book!"
        '''
        if len(params) != 1:
            print("Invalid number of parameters! Expected 1")
            return
        try:
            id_book = int(params[0])
            book = self.__services_books.search_book(id_book)
            print(book)
        except ValueError:
            raise UIError("Non-numeric value for parameter id_book!")

    def __ui_modify_book(self, params):
        '''
        :description: modifies book with given id
        :param params: array of parameters [integer, string, string, string]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_book!"
        '''
        if len(params) != 4:
            print("Invalid number of parameters! Expected 4")
            return
        try:
            id_book = int(params[0])
            new_title = params[1]
            new_author = params[2]
            new_description = params[3]
            self.__services_books.modify_book(id_book, new_title, new_author, new_description)
            print("Book modified with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter id_book!")

    def __ui_modify_client(self, params):
        '''
        :description: modifies client with given id
        :param params: array of parameters [integer, string, string]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_client!"
        '''
        if len(params) != 3:
            print("Invalid number of parameters! Expected 3")
            return
        try:
            id_client = int(params[0])
            new_name = params[1]
            new_cnp = params[2]
            self.__services_client.modify_client(id_client, new_name, new_cnp)
            print("Client modified with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter id_client!")

    def __ui_delete_book(self, params):
        '''
        :description: deletes book with given id
        :param params: array of parameters [integer]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_book!"
        '''
        if len(params) > 1:
            print("Invalid number of parameters! Expected none")
            return
        try:
            id_book = int(params[0])
            self.__services_books.delete_book(id_book)
            print("Book deleted with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter id_book!")

    def __ui_delete_client(self, params):
        '''
        :description: deletes client with given id
        :param params: array of parameters [integer]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_client!"
        '''
        if len(params) > 1:
            print("Invalid number of parameters! Expected none")
            return
        try:
            id_client = int(params[0])
            self.__services_client.delete_client(id_client)
            print("Client deleted with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter id_client!")

    def __ui_print_books(self, params):
        '''
        :description: prints the current book list
        :param params: array of parameters []
        :return: none
        :exception: invalid number of parameters
                    empty book list
        '''
        if len(params) > 0:
            print("Invalid number of parameters! Expected none")
            return
        books = self.__services_books.get_all_books()
        if len(books) == 0:
            print("No available books")
        else:
            for book in books:
                print(book)

    def __ui_add_book(self, params):
        '''
        :description: adds a new Book object
        :param params: array of parameters [integer, string, string, string]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_book!"
        '''
        if len(params) != 4:
            print("Invalid number of parameters! Expected 3")
            return
        try:
            id_book = int(params[0])
            title = params[1]
            author = params[2]
            description = params[3]
            self.__services_books.add_book(id_book, title, author, description)
            print("Book added with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter id_book!")

    def __ui_add_client(self, params):
        '''
        :description: adds a new Client object
        :param params: array of parameters [integer, string, string]
        :return: none
        :exception: invalid number of parameters
                    UIError "Non-numeric value for parameter id_client!"
        '''
        if len(params) != 3:
            print("Invalid number of parameters! Expected 3")
            return
        try:
            id_client = int(params[0])
            name = params[1]
            cnp = params[2]
            self.__services_client.add_client(id_client, name, cnp)
            print("Client added with success!")
        except ValueError:
            raise UIError("Non-numeric value for parameter id_client!")

    def __ui_print_clients(self, params):
        '''
        :description: prints the current client list
        :param params: array of parameters []
        :return: none
        :exception: invalid number of parameters
                    empty client list
        '''
        if len(params) > 0:
            print("Invalid number of parameters! Expected none")
            return
        clients = self.__services_client.get_all_clients()
        if len(clients) == 0:
            print("No available clients")
        else:
            for client in clients:
                print(client)

    def run(self, services_books_file, services_client_file, services_borrow_file):
        '''
        :param: none
        :description: main function for console interface
        :return: none
        :exception: repo errors
                    UI errors
                    validation errors
                    other errors
                    "Invalid command!"
        '''
        print("Use records from file? [y/n]")
        ok = 1
        while ok:
            option = input()
            if option == 'y':
                self.__services_books = services_books_file
                self.__services_client = services_client_file
                self.__services_borrow = services_borrow_file
                ok = 0
            elif option == 'n':
                ok = 0
            else:
                print("Invalid option!")

        while True:
            cmd = input(">>>")
            cmd = cmd.strip()
            if cmd == "exit":
                return
            parts = cmd.split(" ")
            cmd_name = parts[0]
            params = parts[1:]
            if cmd_name in self.__commands:
                try:
                    self.__commands[cmd_name](params)
                except RepoError as ex:
                    print(f"repo error: {ex}")
                except UIError as ex:
                    print(f"UI error: {ex}")
                except ValidationError as ex:
                    print(f"validation error: {ex}")
                except Exception as error:
                    print(error)
            else:
                print("Invalid command!")
