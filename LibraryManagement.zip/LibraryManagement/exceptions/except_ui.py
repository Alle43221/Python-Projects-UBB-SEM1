class UIError(Exception):
    pass