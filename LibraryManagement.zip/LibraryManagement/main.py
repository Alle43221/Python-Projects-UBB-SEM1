from repository.repo_book import BookRepository
from repository.repo_client import ClientRepository
from repository.repo_borrow import BorrowRepository

from repository.repo_borrow import FileRepoBorrow
from repository.repo_client import FileRepoClient
from repository.repo_book import FileRepoBooks

from services.services_book import BookService
from services.services_client import ClientService
from services.services_borrow import BorrowService
from tests.test_book import TestBook
from tests.test_client import TestClient
from tests.test_borrow import TestBorrow
from ui.UI import UI
from validation.validation_book import ValidateBook
from validation.validation_client import ValidateClient
from validation.validation_borrow import ValidateBorrow

validator_books = ValidateBook()
validator_clients = ValidateClient()
validator_borrow = ValidateBorrow()

repo_books = BookRepository()
repo_clients = ClientRepository()
repo_borrow = BorrowRepository()

repo_books_file = FileRepoBooks("repository/books.txt")
repo_clients_file = FileRepoClient("repository/clients.txt")
repo_borrows_file = FileRepoBorrow("repository/borrows.txt")

service_books = BookService(repo_books, validator_books)
service_clients = ClientService(repo_clients, validator_clients)
service_borrow = BorrowService(repo_borrow, repo_books, repo_clients, validator_borrow)

service_clients_file = ClientService(repo_clients_file, validator_clients)
service_books_file = BookService(repo_books_file, validator_books)
service_borrow_file = BorrowService(repo_borrows_file, repo_books_file, repo_clients_file, validator_borrow)

testing_borrows = TestBorrow(validator_borrow, repo_borrow, service_borrow, service_books, service_clients)
testing_clients = TestClient(validator_clients, repo_clients, service_clients)
testing_books = TestBook(validator_books, repo_books, service_books)
testing_clients.run_all_tests()
repo_clients.get_all_clients().clear()
testing_books.run_all_tests()
repo_books.get_all_books_repo().clear()
testing_borrows.run_all_tests()

repo_borrow.get_all_borrow_repo().clear()
repo_clients.get_all_clients().clear()
repo_books.get_all_books_repo().clear()

console = UI(service_books, service_clients, service_borrow)
console.run(service_books_file, service_clients_file, service_borrow_file)
