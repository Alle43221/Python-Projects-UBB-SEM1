from domain.domain_client import Client


class ClientService:
    def __init__(self, repo_clients, validator_client):
        '''
        :description: initializes a new instance of ClientService
        :param repo_clients: ClientRepository instance
        :param validator_client: ValidateClient instance
        :return: none
        '''
        self.__repo_clients = repo_clients
        self.__validator_client = validator_client

    def modify_client(self, id_client, name, cnp):
        '''
        :description: modifies the client with a given id
        :param id_client: integer
        :param name: string
        :param cnp: string
        :return: none
        '''
        client = Client(id_client, name, cnp)
        self.__validator_client.validate_client(client)
        self.__repo_clients.modify_client(client)

    def add_client(self, id_client, name, cnp):
        '''
        :description: appends a new client to list
        :param id_client: integer
        :param name: string
        :param cnp: string
        :return: none
        '''
        client = Client(id_client, name, cnp)
        self.__validator_client.validate_client(client)
        self.__repo_clients.add_client(client)

    def delete_client(self, id_client):
        '''
        :description: deletes the client with a given id
        :param id_client: integer
        :return: none
        '''
        client = Client(id_client, "", "")
        self.__repo_clients.delete_client(client)

    def get_all_clients(self):
        '''
        :description: fetches all the clients from repo
        :return: array of Client objects
        :param: none
        '''
        return self.__repo_clients.get_all_clients()

    def search_client(self, id_client):
        '''
        :description: searches for the client with a given id
        :param id_client: integer
        :return: none
        '''
        client = Client(id_client, "", "")
        return self.__repo_clients.search_client(client)
