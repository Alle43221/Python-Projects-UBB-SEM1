import random
import string

from domain.domain_book import Book


class BookService:
    def __init__(self, repo_books, validator_book):
        '''
        :description: initializes a new instance of BookService
        :param repo_books: BookRepository instance
        :param validator_book: ValidateBook instance
        :return: none
        '''
        self.__repo_books = repo_books
        self.__validator_book = validator_book

    def add_book(self, id_book, title, author, description):
        '''
        :description: appends a new book to list
        :param id_book: integer
        :param title: string
        :param author: string
        :param description:  string
        :return: none
        '''
        book = Book(id_book, title, author, description)
        self.__validator_book.validate_book(book)
        self.__repo_books.add_book(book)

    def delete_book(self, id_book):
        '''
        :description: deletes the book with a given id
        :param id_book: integer
        :return: none
        '''
        book = Book(id_book, "", "", "")
        self.__repo_books.delete_book(book)

    def modify_book(self, id_book, title, author, description):
        '''
        :description: modifies the book with a given id
        :param id_book: integer
        :param title: string
        :param author: string
        :param description: string
        :return: none
        '''
        book = Book(id_book, title, author, description)
        self.__validator_book.validate_book(book)
        self.__repo_books.modify_book1(book, 0)

    def search_book(self, id_book):
        '''
        :description: searches for the book with a given id
        :param id_book: integer
        :return: none
        '''
        book = Book(id_book, "", "", "")
        return self.__repo_books.search_book1(book, 0)

    def generate_books(self, number):
        '''
        :descriiption: generates a number of random books
        :param number: integer
        :return: none
        '''
        generated = 0
        letters = string.ascii_lowercase
        random.seed(5)
        while generated < number:
            new_id = random.randint(1, max(200, number))
            new_title = ''.join(random.sample(letters, 10))
            new_author = ''.join(random.sample(letters, 10))
            new_description = ''.join(random.sample(letters, 20))
            new_book = Book(new_id, new_title, new_author, new_description)
            try:
                self.__validator_book.validate_book(new_book)
                self.__repo_books.add_book(new_book)
                generated = generated + 1
            except:
                pass

    def get_all_books(self):
        '''
        :description: fetches all the books from repo
        :return: array of Book objects
        :param: none
        '''
        return self.__repo_books.get_all_books_repo()
