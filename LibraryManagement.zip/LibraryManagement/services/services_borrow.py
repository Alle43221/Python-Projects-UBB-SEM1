from domain.domain_book import Book
from domain.domain_borrow import Borrow
from domain.domain_client import Client
from domain.dtos import ReportBook, ReportClient
from defined_functions.sort import Sort

class BorrowService:
    def __init__(self, repo_borrow, repo_books, repo_clients, validator_borrow):
        '''
        :description: initializes a new BorrowService instance
        :param repo_borrow: BorrowRepository instance
        :param repo_books: BookRepository instance
        :param repo_clients: ClientRepository instance
        :param validator_borrow: ValidateBorrow instance
        :return: none
        '''
        self.__repo_borrow = repo_borrow
        self.__repo_books = repo_books
        self.__repo_clients = repo_clients
        self.__validator_borrow = validator_borrow

    def add_borrow(self, id_book, id_client):
        '''
        :description: appends a new borrow
        :param id_book: integer
        :param id_client: integer
        :return: none
        '''
        borrow = Borrow(id_book, id_client)
        list_books = self.__repo_books.get_all_books_repo()
        list_clients = self.__repo_clients.get_all_clients()
        self.__validator_borrow.validate_borrow(borrow, list_books, list_clients)
        self.__repo_borrow.add_borrow_repo(borrow)

    def delete_borrow(self, id_book):
        '''
        :param id_book: integer
        :return: none
        :description: deletes active borrow for given book
        '''
        borrow = Borrow(id_book, 0)
        self.__repo_borrow.modify_borrow(borrow)

    def get_all_borrows(self):
        '''
        :return: none
        :param: none
        :description: fetches all borrows from repo
        '''
        return self.__repo_borrow.get_all_borrow_repo()

    def report_popular_books(self):
        '''
        :return: array of dtos
        :param:none
        :description: compiles a list of 5 most popular books, including title, author, id and number of borrows
        '''
        self.__repo_books.get_all_books_repo()
        self.__repo_clients.get_all_clients()
        borrows = self.__repo_borrow.get_all_borrow_repo()
        times_borrowed = {}
        for borrow in borrows:
            id_book = borrow.get_id_book()
            if id_book not in times_borrowed:
                times_borrowed[id_book] = 0
            times_borrowed[id_book] += 1

        result = []
        for book_id in times_borrowed:
            new_book = Book(book_id, "", "", "")
            found_book = self.__repo_books.search_book(new_book)
            title = found_book.get_title()
            author = found_book.get_author()
            times = times_borrowed[book_id]
            dto = ReportBook(title, author, times, book_id)
            result.append(dto)
        sort=Sort()
        result=sort.bubble_sort(result, True, function=(lambda x, y: x.get_times()<y.get_times()))
        #result.sort(key=lambda x: x.get_times(), reverse=True)
        return result[:5]

    def report_top_clients(self):
        '''
            :return: array of dtos
            :description: compiles a list of 10 or 20% most active clients all-time, including name, id,
                and number of books borrowed
        '''
        self.__repo_books.get_all_books_repo()
        self.__repo_clients.get_all_clients()
        borrows = self.__repo_borrow.get_all_borrow_repo()
        clients = {}
        for borrow in borrows:
            id_client = borrow.get_id_client()
            if id_client not in clients:
                clients[id_client] = 0
            clients[id_client] += 1

        result = []
        for client_id in clients:
            new_client = Client(client_id, "", "")
            found_client = self.__repo_clients.search_client(new_client)
            name = found_client.get_name()
            times = clients[client_id]
            dto = ReportClient(name, client_id, times)
            result.append(dto)
        #result.sort(key=lambda x: x.get_books(), reverse=True)
        sort = Sort()
        result = sort.shell_sort(result,function=self.cmp_books_name)
        len_list = len(result)
        if len_list > 10:
            len_list = int(len_list / 5)
        return result[:len_list]

    def cmp_books_name(self, x, y):
        if x.get_books() > y.get_books():
            return 1
        elif x.get_books() == y.get_books():
            if x.get_name() < y.get_name():
                return 1
            else:
                return 0
        else:
            return 0

    def report_active_clients_name(self):
        '''
            :return: array of dtos
            :description: compiles a list of 10 most active clients, with borrowed books, including name, id,
                and number of books currently borrowed, sorted by name
        '''
        borrows = self.__repo_borrow.get_all_borrow_repo()
        clients = {}
        self.__repo_books.get_all_books_repo()
        self.__repo_clients.get_all_clients()
        for borrow in borrows:
            if borrow.get_status()=='active':
                id_client = borrow.get_id_client()
                if id_client not in clients:
                    clients[id_client] = 0
                clients[id_client] += 1

        result = []
        for client_id in clients:
            new_client = Client(client_id, "", "")
            found_client = self.__repo_clients.search_client(new_client)
            name = found_client.get_name()
            times = clients[client_id]
            dto = ReportClient(name, client_id, times)
            result.append(dto)

        result.sort(key=lambda x: x.get_name())
        #result.sort(key=lambda x: x.get_name())
        len_list = len(result)
        return result[:min(len_list, 10)]

    def report_active_clients_books(self):
        '''
            :return: array of dtos
            :description: compiles a list of 10 most active clients, with borrowed books, including name, id,
                    and number of books currently borrowed, sorted by the last field
        '''
        borrows = self.__repo_borrow.get_all_borrow_repo()
        clients = {}
        self.__repo_books.get_all_books_repo()
        self.__repo_clients.get_all_clients()
        for borrow in borrows:
            if borrow.get_status() == 'active':
                id_client = borrow.get_id_client()
                if id_client not in clients:
                    clients[id_client] = 0
                clients[id_client] += 1

        result = []
        for client_id in clients:
            new_client = Client(client_id, "", "")
            found_client = self.__repo_clients.search_client(new_client)
            name = found_client.get_name()
            times = clients[client_id]
            dto = ReportClient(name, client_id, times)
            result.append(dto)
        result.sort(key=lambda x: x.get_books(), reverse=True)
        len_list = len(result)
        return result[:min(10, len_list)]
