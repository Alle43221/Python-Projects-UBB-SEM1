from domain.domain_borrow import Borrow
from exceptions.except_repo import RepoError

class BorrowRepository:
    def __init__(self):
        '''
        :param: none
        :description: initializes an empty borrow list
        '''
        self._borrow_list = []

    def get_size(self):
        '''
        :param: none
        :return: integer
        :description: returns number of Borrow objects in list
        '''
        return len(self._borrow_list)

    def search_borrow(self, borrow):
        '''
        :description: searches a given borrow
        :param borrow: Borrow object
        :return: Book object
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''
        if len(self._borrow_list) == 0:
            raise RepoError("No available borrows!")
        for i in self._borrow_list:
            if i == borrow:
                return i
        raise RepoError("Non-existing borrow!")

    def get_all_borrow_repo(self):
        '''
        :param: none
        :return: array of Borrow objects
        :description: returns the borrow list
        '''
        return self._borrow_list

    def add_borrow_repo(self, new_borrow):
        '''
        :param new_borrow: Borrow object
        :return: none
        :exception: Repo Error - Existing record! - book is already borrowed
        :description: appends a new Borrow object to the list
        '''
        for i in self._borrow_list:
            if i == new_borrow:
                raise RepoError("Existing record!")

        self._borrow_list.append(new_borrow)

    def modify_borrow(self, borrow):
        '''
        :param borrow: Borrow object
        :return: none
        :description: modifies a given borrow
        :exception: Repo Error - No available borrow list! - borrow list empty
                    Repo Error - Non-existing borrow! - no active borrow for given book found
        '''
        if len(self._borrow_list) == 0:
            raise RepoError("No available borrow list!")
        for i in self._borrow_list:
            if i == borrow:
                i.set_status("returned")
                return
        raise RepoError("Non-existing borrow!")


class FileRepoBorrow(BorrowRepository):
    def __init__(self, file_path):
        '''
        :description: initializes a new FileRepoBorrow instance
        :param file_path: string
        :return: none
        '''
        BorrowRepository.__init__(self)
        self.__file_path = file_path

    def __read_all_borrows_from_file(self):
        '''
        :description: loads all borrows from file
        :return: none
        :param: none
        '''
        with open(self.__file_path, "r") as f:
            self._borrow_list.clear()
            lines = f.readlines()
            for line in lines:
                if line != "":
                    parts = line.split(" ")
                    id_book = int(parts[0])
                    id_client = int(parts[1])
                    status = parts[2].rstrip('\n')
                    borrow = Borrow(id_book, id_client)
                    borrow.set_status(status)
                    self._borrow_list.append(borrow)

    def __write_all_borrows_to_file(self):
        '''
        :description: saves all books to file
        :return: none
        :param: none
        '''
        with open(self.__file_path, "w") as f:
            for id_borrow in self._borrow_list:
                f.write(str(id_borrow) + '\n')

    def get_size(self):
        '''
        :param: none
        :return: integer
        :description: returns number of Borrow objects in list
        '''
        self.__read_all_borrows_from_file()
        BorrowRepository.get_size(self)

    def search_borrow(self, borrow):
        '''
        :description: searches a given borrow
        :param borrow: Borrow object
        :return: Book object
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''
        self.__read_all_borrows_from_file()
        return BorrowRepository.search_borrow(self, borrow)

    def get_all_borrow_repo(self):
        '''
        :param: none
        :return: array of Borrow objects
        :description: returns the borrow list
        '''
        self.__read_all_borrows_from_file()
        return BorrowRepository.get_all_borrow_repo(self)

    def add_borrow_repo(self, new_borrow):
        '''
        :param new_borrow: Borrow object
        :return: none
        :exception: Repo Error - Existing record! - book is already borrowed
        :description: appends a new Borrow object to the list
        '''
        self.__read_all_borrows_from_file()
        BorrowRepository.add_borrow_repo(self, new_borrow)
        self.__write_all_borrows_to_file()

    def modify_borrow(self, borrow):
        '''
        :param borrow: Borrow object
        :return: none
        :description: modifies a given borrow
        :exception: Repo Error - No available borrow list! - borrow list empty
                    Repo Error - Non-existing borrow! - no active borrow for given book found
        '''
        self.__read_all_borrows_from_file()
        BorrowRepository.modify_borrow(self, borrow)
        self.__write_all_borrows_to_file()
