from domain.domain_book import Book
from exceptions.except_repo import RepoError
import re


class BookRepository:
    def __init__(self):
        '''
        :param: none
        :description: initializes an empty book list
        :return: none
        '''
        self._books = []

    def get_size(self):
        '''
        :return: integer
        :param: none
        :description: gets the number of books in list
        '''
        return len(self._books)

    def modify_book(self, book):
        '''
        :description: modifies a given book
        :param book: Book object
        :return: none
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''
        len1 = self.get_size()
        if len1 == 0:
            raise RepoError("No available books!")

        for i in range(0, len1):
            if self._books[i] == book:
                self._books[i] = book
                return
        raise RepoError("Non-existing book!")

    def modify_book1(self, book, i):
        '''
        :param i: index integer
        :description: modifies a given book
        :param book: Book object
        :return: none
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''

        '''
        A DOUA FUNCTIE IMPLEMENTATA RECURSIV
        '''
        len1 = self.get_size()
        if len1 == 0:
            raise RepoError("No available books!")
        if len(self._books) == i:
            raise RepoError("Non-existing book!")
        else:
            if self._books[i] == book:
                self._books[i] = book
                return
            else:
                return self.modify_book1(book, i + 1)

    def add_book(self, book):
        '''
        :description: appends a new Book object
        :param book: Book object
        :return: none
        :exception: RepoError "Existing ID!"
        '''
        for i in self._books:
            if i == book:
                raise RepoError("Existing ID!")
        self._books.append(book)

    def delete_book(self, book):
        '''
        :description: deletes Book object
        :param book: Book object
        :return: none
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''
        if len(self._books) == 0:
            raise RepoError("No available books!")
        for i in self._books:
            if i == book:
                self._books.remove(i)
                return
        raise RepoError("Non-existing book!")

    def search_book(self, book):
        '''
        :description: searches a given book
        :param book: Book object
        :return: Book object
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''

        '''
        ANALIZA COMPLEXITATE:
        cazul favorabil: cartea cautata se afla la inceputul vectorului (pe prima pozitie)
            CF -> T(n)= 1
        cazul defavorabil: cartea cautata nu se afla in vector
            CD -> T(n)= n
        cazul mediu: T(n)= (1+2+3+...+n)/n = n*(n+1)/2/n=(n+1)/2

        deci T(n) apartine O(n)
        '''

        if len(self._books) == 0:
            raise RepoError("No available books!")
        for i in self._books:
            if i == book:
                return i
        raise RepoError("Non-existing book!")

    def search_book1(self, book, i):
        '''
        :param i: index integer
        :description: searches a given book
        :param book: Book object
        :return: Book object
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''

        '''
        PRIMA FUNCTIE IMPLEMENTATA RECURSIV:
        '''

        if len(self._books) == 0:
            raise RepoError("No available books!")
        if len(self._books) == i:
            raise RepoError("Non-existing book!")
        else:
            if self._books[i] == book:
                return self._books[i]
            else:
                return self.search_book1(book, i + 1)

    def get_all_books_repo(self):
        '''
        :description: fetches all the books from repo
        :return: array of Book objects
        :param: none
        '''
        return self._books


class FileRepoBooks(BookRepository):
    def __init__(self, file_path):
        '''
        :description: initializes a new FileRepoBooks instance
        :param file_path: string
        :return: none
        '''
        BookRepository.__init__(self)
        self.__file_path = file_path

    def __read_all_books_from_file(self):
        '''
        :description: loads all books from file
        :return: none
        :param: none
        '''
        with open(self.__file_path, "r") as f:
            self._books.clear()
            lines = f.readlines()
            len1 = len(lines)
            i = 0
            while i < len1:
                if lines[i] != "":
                    id_book = int(lines[i])
                    title = lines[i + 1].rstrip('\n')
                    author = lines[i + 2].rstrip('\n')
                    description = lines[i + 3].rstrip('\n')
                    i += 4
                    new_book = Book(id_book, title, author, description)
                    self._books.append(new_book)

    def __write_all_books_to_file(self):
        '''
        :description: saves all books to file
        :return: none
        :param: none
        '''
        with open(self.__file_path, "w") as f:
            for id_book in self._books:
                f.write(str(id_book.get_id_book()) + '\n')
                f.write(str(id_book.get_title()) + '\n')
                f.write(str(id_book.get_author()) + '\n')
                f.write(str(id_book.get_description()) + '\n')

    def add_book(self, book):
        '''
        :description: appends a new book and saves it to file
        :param book: Book object
        :return: none
        '''
        self.__read_all_books_from_file()
        BookRepository.add_book(self, book)
        self.__write_all_books_to_file()

    def get_all_books_repo(self):
        '''
        :description: fetches the book list
        :return: array of Book objects
        :param: none
        '''
        self.__read_all_books_from_file()
        return BookRepository.get_all_books_repo(self)

    def get_size(self):
        '''
        :return: integer
        :param: none
        :description: gets the number of books in list
        '''
        self.__read_all_books_from_file()
        return BookRepository.get_size(self)

    def modify_book1(self, book, i):
        '''
        :param i: integer index
        :description: modifies a given book
        :param book: Book object
        :return: none
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''
        self.__read_all_books_from_file()
        BookRepository.modify_book1(self, book, 0)
        self.__write_all_books_to_file()

    def delete_book(self, book):
        '''
        :description: deletes Book object
        :param book: Book object
        :return: none
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''
        self.__read_all_books_from_file()
        BookRepository.delete_book(self, book)
        self.__write_all_books_to_file()

    def search_book1(self, book, i):
        '''
        :param i: index integer
        :description: searches a given book
        :param book: Book object
        :return: Book object
        :exception: RepoError "No available books!"
                    RepoError "Non-existing book!"
        '''
        self.__read_all_books_from_file()
        return BookRepository.search_book1(self, book, 0)
