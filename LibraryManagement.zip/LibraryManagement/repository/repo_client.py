from domain.domain_client import Client
from exceptions.except_repo import RepoError
import re


class ClientRepository:
    def __init__(self):
        '''
        :param: none
        :description: initializes an empty client list
        :return: none
        '''
        self._clients = []

    def get_size(self):
        '''
        :return: integer
        :param: none
        :description: gets the number of clients in list
        '''
        return len(self._clients)

    def modify_client(self, client):
        '''
        :description: modifies a given client
        :param client: Client object
        :return: none
        :exception: RepoError "No available clients!"
                    RepoError "Non-existing clients!"
        '''
        len1 = self.get_size()
        if len1 == 0:
            raise RepoError("No available clients!")
        for i in range(0, len1):
            if self._clients[i] == client:
                self._clients[i] = client
                return
        raise RepoError("Non-existing client!")

    def add_client(self, client):
        '''
        :description: appends a new Client object
        :param client: Client object
        :return: none
        :exception: RepoError "Existing ID!"
        '''
        for i in self._clients:
            if i == client:
                raise RepoError("Existing ID!")
        self._clients.append(client)

    def delete_client(self, client):
        '''
       :description: deletes Client object
       :param client: Client object
       :return: none
       :exception: RepoError "No available clients!"
                   RepoError "Non-existing client!"
       '''
        if len(self._clients) == 0:
            raise RepoError("No available clients!")
        for i in self._clients:
            if i == client:
                self._clients.remove(i)
                return
        raise RepoError("Non-existing client!")

    def search_client(self, client):
        '''
        :description: searches a given client
        :param client: Client object
        :return: Client object
        :exception: RepoError "No available clients!"
                    RepoError "Non-existing client!"
        '''
        if len(self._clients) == 0:
            raise RepoError("No available clients!")
        for i in self._clients:
            if i == client:
                return i
        raise RepoError("Non-existing client!")

    def get_all_clients(self):
        '''
        :description: fetches all the clients from repo
        :return: array of Client objects
        :param: none
        '''
        return self._clients


class FileRepoClient(ClientRepository):
    def __init__(self, file_path):
        '''
        :description: initializes a new FileRepoClient instance
        :param file_path: string
        :return: none
        '''
        ClientRepository.__init__(self)
        self.__file_path = file_path

    def __read_all_clients_from_file(self):
        '''
        :description: loads all clients from file
        :return: none
        :param: none
        '''
        with open(self.__file_path, "r") as f:
            self._clients.clear()
            lines = f.readlines()
            for line in lines:
                if line != "":
                    parts = re.split(r"[\s]", line)
                    id_client = int(parts[0])
                    name = parts[1]
                    cnp = parts[2]
                    new_client = Client(id_client, name, cnp)
                    self._clients.append(new_client)

    def __write_all_clients_to_file(self):
        '''
        :description: saves all clients to file
        :return: none
        :param: none
        '''
        with open(self.__file_path, "w") as f:
            for id_client in self._clients:
                f.write(str(id_client) + "\n")

    def add_client(self, client):
        '''
        :description: appends a new client and saves it to file
        :param client: Client object
        :return: none
        '''
        self.__read_all_clients_from_file()
        ClientRepository.add_client(self, client)
        self.__write_all_clients_to_file()

    def get_all_clients(self):
        '''
        :description: fetches the client list
        :return: array of Client objects
        :param: none
        '''
        self.__read_all_clients_from_file()
        return ClientRepository.get_all_clients(self)

    def search_client(self, client):
        '''
        :description: searches a given client
        :param client: Client object
        :return: Client object
        :exception: RepoError "No available clients!"
                    RepoError "Non-existing client!"
        '''
        self.__read_all_clients_from_file()
        return ClientRepository.search_client(self, client)

    def delete_client(self, client):
        '''
       :description: deletes Client object
       :param client: Client object
       :return: none
       :exception: RepoError "No available clients!"
                   RepoError "Non-existing client!"
       '''
        self.__read_all_clients_from_file()
        ClientRepository.delete_client(self, client)
        self.__write_all_clients_to_file()

    def modify_client(self, client):
        '''
        :description: modifies a given client
        :param client: Client object
        :return: none
        :exception: RepoError "No available clients!"
                    RepoError "Non-existing clients!"
        '''
        self.__read_all_clients_from_file()
        ClientRepository.modify_client(self, client)
        self.__write_all_clients_to_file()

    def get_size(self):
        '''
        :return: integer
        :param: none
        :description: gets the number of clients in list
        '''
        self.__read_all_clients_from_file()
        ClientRepository.get_size(self)