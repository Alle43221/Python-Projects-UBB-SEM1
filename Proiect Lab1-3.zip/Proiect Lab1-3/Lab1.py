
s=0
n=input()
n=int(n)
for i in range (0, n):
    a=input()
    a=int(a)
    s=s+a
print(s)

"""

n=input()
n=int(n)
prim=1
    
for i in range (2, n):
    if n%i==0:
        prim=0

if n<=1:
    prim=0
    
if prim==1:
    print("prim")
else: print("compus")


a=int(input())
b=int(input())

while b!=0:
    r=a%b
    a=b
    b=r
    
print(a)

"""
