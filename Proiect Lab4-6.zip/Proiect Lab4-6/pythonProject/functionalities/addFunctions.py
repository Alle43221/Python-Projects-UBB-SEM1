from functionalities.utilities.classFunctions import append_to_database, create_new_Package, save_history, Packet
from functionalities.utilities.inputFunctions import read_destination, read_date, read_price, read_id, read_second_date
from functionalities.utilities.listOperations import search_packet_by_id
from writeOptions import write_packet

def add(database):
    '''
    :param database:  [[],[]] of type array of Packet
    :return: none
    :description: read and appends the data for a new packet
    '''

    print("Type the start date in format: DD/MM/YYYY")
    start_obj=read_date()

    print("Type the end date in format: DD/MM/YYYY")
    end_obj=read_second_date(start_obj)

    print("Type the destination:")
    destination_obj=read_destination()

    print("Type the price:")
    price_obj=read_price()

    print("Type the id:")
    id_obj = read_id(database[0])

    save_history(database)
    append_to_database(database, create_new_Package(start_obj, end_obj, destination_obj, price_obj, id_obj))
    print("Packet added")

def modify(database):
    '''
        :param database:  [[],[]] of type array of Packet
        :return: none
        :description: reads an id and modifies the corresponding packet
        :exceptions: database[0] is empty or no packets found
        '''

    print("Type the id of the packet:")
    id_obj=read_price()

    item=search_packet_by_id(database[0], id_obj)
    if item is not None:
        save_history(database)
        print("Modifying packet:")
        write_packet(item)
        database[0].remove(item)

        print("Type the start date in format: DD/MM/YYYY")
        start_obj = read_date()

        print("Type the end date in format: DD/MM/YYYY")
        end_obj=read_second_date(start_obj)

        print("Type the destination:")
        destination_obj = read_destination()

        print("Type the price:")
        price_obj = read_price()

        print("Packet modified")

        newPacket=Packet(start_obj, end_obj, destination_obj, price_obj, id_obj)
        write_packet(newPacket)
        append_to_database(database, newPacket)

    else :
        print("No packet found")