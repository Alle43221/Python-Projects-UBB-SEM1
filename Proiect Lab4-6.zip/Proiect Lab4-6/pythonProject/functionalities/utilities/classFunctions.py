from datetime import datetime

from writeOptions import write_results_query


class Packet:
    def __init__(self, start_date, end_date, destination, price, id1):
        self.__id = id1
        self.__start_date = start_date
        self.__end_date = end_date
        self.__destination = destination
        self.__price = price

    def get_start_date(self):
        return self.__start_date

    def get_end_date(self):
        return self.__end_date

    def get_destination(self):
        return self.__destination

    def get_id(self):
        return self.__id

    def get_price(self):
        return self.__price

    def set_id(self, new_id):
        self.__id = new_id

    def set_start_date(self, new_start_date):
        self.__start_date = new_start_date

    def set_end_date(self, new_end_date):
        self.__end_date = new_end_date

    def set_destination(self, new_destination):
        self.__destination = new_destination

    def set_price(self, new_price):
        self.__price = new_price

    def __eq__(self, other):
        if isinstance(other, self.__class__):
            return self.__id == other.__id
        return False

    def __str__(self):
        return f'Start date: {self.get_start_date()} \n End date: {self.get_end_date()}\n Destination:{self.get_destination()}\n Price:{self.get_price()}\n Id:{self.get_id()}'

    def __ne__(self, other):
        return not self.__eq__(other)


date_format = '%d/%m/%Y'


def init_Packet_DB():
    '''
    :description: builds an empty array containing the current list of packets and a history of them
    :return: array of two arrays
    '''
    db = [[], []]
    '''
    db[0] -> array of available packets
    db[1] -> array of array of packets (history)
    '''
    return db


def init_Packet_DB_tester():
    assert init_Packet_DB() == [[], []]


def create_new_Package(start_obj, end_obj, destination_obj, price_obj, id):
    '''
    :param start_obj: datetime object
    :param end_obj: datetime object
    :param destination_obj: string
    :param price_obj: integer
    :return: Packet object
    :description: creates new Packet object with the given values
    '''
    newPacket = Packet(start_obj, end_obj, destination_obj, price_obj, id)
    return newPacket

def create_new_Package_tester():
    newPacket1=create_new_Package(datetime(2023, 12, 11, 0, 0), datetime(2023, 12, 13, 0, 0), 'London', 75, 12)
    newPacket2=create_new_Package(datetime(2023, 12, 11, 0, 0), datetime(2023, 12, 13, 0, 0), 'London', 75, 12)
    newPacket3=create_new_Package(datetime(2023, 12, 11, 0, 0), datetime(2023, 12, 13, 0, 0), 'London', 75, 11)
    assert newPacket1==newPacket2
    assert newPacket1!=newPacket3

def append_to_database(database, newPacket):
    '''
    :param database: [[], []] of Packets
    :param newPacket: Packet object
    :return: none
    :description: appends newPacket to the database list
    '''
    database[0].append(newPacket)


def get_number_of_days(item):
    '''
    :param item: Packet object
    :return: integer
    :description: calculates the number of days between the start date and end date for a given object
    '''
    d0 = item.get_end_date()
    d1 = item.get_start_date()
    delta = d0 - d1
    return delta.days + 1

def get_number_of_days_tester():
    item = Packet(datetime(2023, 12, 11), datetime(2023, 12, 15), "London", 150, 11)
    assert (get_number_of_days(item) == 5)
    item = Packet(datetime(2023, 12, 11), datetime(2023, 12, 11), "London", 150, 11)
    assert (get_number_of_days(item) == 1)

def save_history(database):
    '''
    :description: appends the current database of packets from database[0] to database[1]
    :param database: [[], []] of Packet objects
    :return: none
    '''
    new_history = database[0].copy()
    #write_results_query(new_history)
    database[1].append(new_history)
