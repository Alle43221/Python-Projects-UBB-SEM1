from datetime import datetime

def Packet(start_date, end_date, destination, price):
    packet = {
        "start_date": start_date,
        "end_date": end_date,
        "destination": destination,
        "price": price
    }
    return packet

def get_start_date(self):
    return self['start_date']

def get_end_date(self):
    return self['end_date']

def get_destination(self):
    return self['destination']

def get_id(self):
    return id(self)

def get_price(self):
    return self['price']

def set_start_date(self, new_start_date):
    self['start_date']=new_start_date

def set_end_date(self, new_end_date):
    self['end_date'] = new_end_date

def set_destination(self, new_destination):
    self["destination"]=new_destination

def set_price(self, new_price):
    self["price"] = new_price

def str_print(self):
    return f'Start date: {self.get_start_date()} \n End date: {self.get_end_date()}\n Destination:{self.get_destination()}\n Price:{self.get_price()}\n Id:{self.get_id()}'

date_format = '%d/%m/%Y'


def init_Packet_DB():
    '''
    :description: builds an empty array containing the current list of packets and a history of them
    :return: array of two arrays
    '''
    db = [[], []]
    '''
    db[0] -> array of available packets
    db[1] -> array of array of resulting packets (history)
    '''
    return db

def init_Packet_DB_tester():
    assert init_Packet_DB()==[[], []]

def create_new_Package(start_obj, end_obj, destination_obj, price_obj):
    '''
    :param start_obj: datetime object
    :param end_obj: datetime object
    :param destination_obj: string
    :param price_obj: integer
    :return: Packet object
    :description: creates new Packet object with the given values
    '''
    newPacket = Packet(start_obj, end_obj, destination_obj, price_obj)
    return newPacket

def create_new_Package_tester():
   assert create_new_Package(datetime(2023, 12, 11, 0, 0), datetime(2023, 12, 13, 0, 0), 'London', 75)=={'start_date': datetime(2023, 12, 11, 0, 0), 'end_date': datetime(2023, 12, 13, 0, 0),'destination': 'London', 'price': 75}

def append_to_database(database, newPacket):
    '''
    :param database: arrays of Packets
    :param newPacket: Packet object
    :return: none
    :description: appends newPacket to the database list
    '''
    database.append(newPacket)
    #print(database)

def get_number_of_days(item):
    '''
    :param item: Packet object
    :return: integer
    :description: calculates the number of days between the start date and end date for a given object
    '''
    d0 = get_end_date(item)
    d1 = get_start_date(item)
    delta = d0-d1
    return delta.days+1

def get_number_of_days_tester():
    item=Packet(datetime(2023, 12, 11), datetime(2023, 12, 15), "London", 150)
    assert (get_number_of_days(item)==5)
    item = Packet(datetime(2023, 12, 11), datetime(2023, 12, 11), "London", 150)
    assert (get_number_of_days(item) == 1)