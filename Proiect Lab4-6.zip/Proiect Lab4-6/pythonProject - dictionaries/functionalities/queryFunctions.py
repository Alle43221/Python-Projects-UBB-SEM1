from functionalities.utilities.listOperations import search_in_list_end_date, search_in_list_interval, search_in_list_destination_price
from writeOptions import write_results_query
from functionalities.utilities.inputFunctions import read_destination, read_date, read_price

def q_duration(database):
    '''
    :param database:  [[],[]] of type array of Packet
    :return: none
    description: query the offers for the ones with both dates in a given interval
    '''
    print("Type the start date in format: DD/MM/YYYY")
    start_obj=read_date()
    print("Type the end date in format: DD/MM/YYYY")
    end_obj=read_date()
    write_results_query(search_in_list_interval(database[0],start_obj, end_obj))

def q_destination_price(database):
    '''

    :param database: [[],[]] of type array of Packet
    :return: none
    :description: query the offers for the ones with a given destination and a price smaller
    than a mentioned value
    '''
    print("Type the destination:")
    destination_obj=read_destination()
    print("Type the maximum price:")
    price_obj=read_price()
    write_results_query(search_in_list_destination_price(database[0], destination_obj, price_obj))

def q_end_date(database):
    '''
    :param database: [[],[]] of type array of Packet
    :return: none
    :description: query the offers for the ones with a given end date
    '''
    print("Type the end date:")
    end_obj=read_date()
    write_results_query(search_in_list_end_date(database[0], end_obj))