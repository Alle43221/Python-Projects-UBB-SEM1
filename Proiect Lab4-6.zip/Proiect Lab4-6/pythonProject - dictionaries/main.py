from tester import global_tester
from userMenu import *
from writeOptions import write_options

global_tester()
write_options()
menu()
