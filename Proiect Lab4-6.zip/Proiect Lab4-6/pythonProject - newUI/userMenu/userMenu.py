from functionalities.addFunctions import *
from functionalities.deleteFunctions import *
from functionalities.queryFunctions import *
from functionalities.reportFunctions import *
from functionalities.filterFunctions import *
from functionalities.utilities.classFunctions import *
from functionalities.undoFunction import undo
from userMenu.writeOptions import *

def menu():
    '''
    :return: none
    :description: main menu
    :exception: invalid value for menu
    '''
    database = init_Packet_DB()
    while 1:
        try:
            cerinta = int(input())
            match cerinta:
                case 0:
                    print_database(database[0])
                case 1:
                    write_options1()
                    menu1(database)
                case 2:
                    write_options2()
                    menu2(database)
                case 3:
                    write_options3()
                    menu3(database)
                case 4:
                    write_options4()
                    menu4(database)
                case 5:
                    write_options5()
                    menu5(database)
                case 6:
                    write_options6()
                    undo(database)
                case 7:
                    exit()
                case _:
                    print("Invalid value for master menu")
        except:
            print("Invalid value for master menu")


def menu1(database):
    '''
    :param database: [[], []] of Packet objects
    :return: none
    :description: menu for add options
    :exception: invalid value for menu
    '''
    cerinta = int(input())
    map={1: add, 2 : modify}
    try:
        map[cerinta](database)
    except:
        print("Invalid value for menu 1")

def menu2(database):
    '''
        :param database: [[], []] of Packet objects
        :return: none
        :description: menu for delete options
        :exception: invalid value for menu
        '''
    cerinta = int(input())
    map={1: del_destination, 2 : del_duration, 3:del_price}
    try:
        map[cerinta](database)
    except:
        print("Invalid value for menu 2")

def menu3(database):
    '''
        :param database: [[], []] of Packet objects
        :return: none
        :description: menu for query options
        :exception: invalid value for menu
        '''
    cerinta = int(input())
    map={1: q_duration, 2 : q_destination_price, 3:q_end_date}
    try:
        map[cerinta](database)
    except:
        print("Invalid value for menu 3")

def menu4(database):
    '''
        :param database: [[], []] of Packet objects
        :return: none
        :description: menu for report options
        :exception: invalid value for menu
        '''
    cerinta = int(input())
    map={1: r_destination, 2 : r_duration, 3:r_price_avg}
    try:
        map[cerinta](database)
    except:
        print("Invalid option for menu 4")

def menu5(database):
    '''
        :param database: [[], []] of Packet objects
        :return: none
        :description: menu for filter options
        :exception: invalid value for menu
        '''
    cerinta = int(input())
    map={1: f_price_dest, 2 : f_month}
    try:
        map[cerinta](database)
    except:
        print("Invalid value for menu 5")