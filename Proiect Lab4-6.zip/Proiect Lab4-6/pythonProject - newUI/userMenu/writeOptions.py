def write_options():
    '''
    :return: none
    :description: prints the main menu with its 7 options
    '''
    print("Menu:")
    print("0. PRINT")
    print("1. ADD")
    print("2. DELETE")
    print("3. QUERY")
    print("4. REPORT")
    print("5. FILTER")
    print("6. UNDO")
    print("7. EXIT")

def write_options1():
    '''
        :return: none
        :description: prints the menu for option 1
    '''
    print("ADD:")
    print("1. ADD TRAVEL PACKET")
    print("2. MODIFY TRAVEL PACKET")

def write_options2():
    '''
           :return: none
           :description: prints the menu for option 2
       '''
    print("DELETE:")
    print("1. DELETE ALL PACKETS WITH A SPECIFIED DESTINATION")
    print("2. DELETE ALL PACKETS WITH A DURATION SMALLER THAN A SPECIFIED NUMBER OF DAYS")
    print("3. DELETE ALL PACKETS WITH A PRICE LARGER THAN A SPECIFIED AMOUNT")

def write_options3():
    '''
           :return: none
           :description: prints the menu for option 3
       '''
    print("QUERY:")
    print("1. PRINT ALL THE PACKETS WHICH TAKE PLACE BETWEEN TWO SPECIFIED DATES")
    print("2. PRINT ALL THE PACKETS WITH A GIVEN DESTINATION AND AND A PRICE SMALLER THAN A GIVEN AMOUNT")
    print("3. PRINT ALL THE PACKETS WITH A GIVEN END DATE")

def write_options4():
    '''
           :return: none
           :description: prints the menu for option 4
       '''
    print("REPORT:")
    print("1. PRINT THE NUMBER OF PACKETS WHICH TAKE PLACE AT A SPECIFIED DESTINATION")
    print("2. PRINT ALL THE PACKETS WHICH TAKE PLACE BETWEEN TWO SPECIFIED DATES IN ASCENDING ORDER OF THE PRICE")
    print("3. PRINT THE AVERAGE PRICE OF PACKETS WITH A GIVEN DESTINATION")

def write_options5():
    '''
           :return: none
           :description: prints the menu for option 5
       '''
    print("FILTER:")
    print("1. PRINT ONLY THE PACKETS WITH A SMALLER OR EQUAL PRICE THAN A SPECIFIED VALUE AND THE GIVEN DESTINATION")
    print("2. PRINT ONLY THE PACKETS WHICH TAKE PLACE OUTSIDE OF A GIVEN MONTH")

def write_options6():
    '''
           :return: none
           :description: prints the description for menu 6
    '''
    print("UNDO THE LAST OPERATION")

def write_results_query(list):
    '''
    :param list: array of type Packet
    :return: none
    :description: prints an array of type Packet or prints 'No results' if the array is empty
    '''
    if len(list)==0:
        print("No results")
    else:
        print("Results of query:")
        for i in list:
            print(str(i))

def print_database(list1):
    '''
    :param list1: array of Packet
    :return: none
    :description: prints all the packets in current database
    :exception: list1 is empty
    '''
    if len(list1)==0:
        print("No packets in database")
    for i in list1:
        print(str(i))

def write_packet(item):
    '''
    :param item: Packet object
    :return: none
    :description: writes a single packet
    '''
    print(str(item))

