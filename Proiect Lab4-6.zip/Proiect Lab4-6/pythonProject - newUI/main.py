from new_Ui.new_UI import new_UI
from functionalities.tester import global_tester
from userMenu.userMenu import *

global_tester()
#write_options()
new_UI()
menu()
