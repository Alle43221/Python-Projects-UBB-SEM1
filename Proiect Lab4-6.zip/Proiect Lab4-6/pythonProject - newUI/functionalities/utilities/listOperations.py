import datetime

from functionalities.utilities.checkConditions import *
from functionalities.utilities.classFunctions import get_number_of_days

def search_in_list_destination_price(list, destination_obj, price_obj):
    '''
            :param list, destination_obj, price_obj: [] array of type Packet, string, integer
            :return results: [] array of Packet
            :description: finds the list of offers with the
            destination=destination_obj and price<price_obj
    '''
    results = []
    for i in list:
        #print(str(i))
        if check_destination(i, destination_obj) and check_price(i, price_obj)==2:
            results.append(i)
    return results

def search_in_list_destination_price_tester():
    assert search_in_list_destination_price([], 'London', 150)==[]
    database1=[Packet(datetime(2023, 12, 10, 0, 0),  datetime(2023, 12, 14, 0, 0), 'London',  90, 11)]
    assert search_in_list_destination_price(database1, 'London', 150)==database1
    database1.append(Packet(datetime(2023, 12, 7, 0, 0),  datetime(2023, 12, 10, 0, 0), 'Brasov',  75, 12))
    assert search_in_list_destination_price(database1, 'London',150)==[database1[0]]
    database1.pop()
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'London', 175, 13))
    assert search_in_list_destination_price(database1, 'London', 150) == [database1[0]]
    assert search_in_list_destination_price(database1, 'London', 10) == []
def search_in_list_destination_price_reverse(list, destination_obj, price_obj):
    '''
            :param list, destination_obj, price_obj: [] array of type Packet, string, integer
            :return results: [] array of Packet
            :description: finds the list of offers with the
            destination!=destination_obj and price>=price_obj
       '''
    results = []
    for i in list:
        if check_destination(i, destination_obj)==1 and check_price(i, price_obj)!=0:
            results.append(i)
    return results

def search_in_list_destination_price_reverse_tester():
    assert search_in_list_destination_price_reverse([], 'London', 150)==[]
    database1=[Packet(datetime(2023, 12, 10, 0, 0),  datetime(2023, 12, 14, 0, 0), 'Brasov',  90, 11)]
    assert search_in_list_destination_price_reverse(database1, 'Brasov', 150)==database1
    assert search_in_list_destination_price_reverse(database1, 'London', 150) == []

    database1.append(Packet(datetime(2023, 12, 7, 0, 0),  datetime(2023, 12, 10, 0, 0), 'London',  75, 12))
    assert search_in_list_destination_price_reverse(database1, 'London', 150) ==[database1[1]]
    database1.pop()
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'London', 175, 13))
    assert search_in_list_destination_price_reverse(database1, 'London', 150) == []

    database1.pop()
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'Brasov', 175, 14))
    assert search_in_list_destination_price_reverse(database1, 'Brasov', 150) == [database1[0]]

def search_in_list_interval(list,start_obj, end_obj):
    '''
               :param list: [] array of Packet,
               :param end_obj: datetime object,
               :param start_obj: datetime object
               :return results: [] array of Packet
               :description: finds the list of offers with both
               dates in a given interval
    '''
    results = []
    for i in list:
        if check_interval(i, start_obj, end_obj):
            results.append(i)
    return results

def search_in_list_interval_tester():
    assert search_in_list_interval([], datetime(2023, 12, 14, 0, 0), datetime(2023, 12, 15, 0, 0)) == []
    database1 = [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11)]
    assert search_in_list_interval(database1, datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 16, 0, 0)) == [database1[0]]
    assert search_in_list_interval(database1, datetime(2023, 12, 13, 0, 0),  datetime(2023, 12, 14, 0, 0)) == []
    assert search_in_list_interval(database1, datetime(2023, 12, 10, 0, 0),  datetime(2023, 12, 13, 0, 0)) == []
    assert search_in_list_interval(database1, datetime(2023, 12, 3, 0, 0),  datetime(2023, 12, 7, 0, 0)) == []
    assert search_in_list_interval(database1, datetime(2023, 12, 20, 0, 0),  datetime(2023, 12, 24, 0, 0)) == []

    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 9, 0, 0), 'Brasov', 90, 10))
    assert search_in_list_interval(database1, datetime(2023, 12, 6, 0, 0),  datetime(2023, 12, 10, 0, 0)) == [database1[1]]
    assert search_in_list_interval(database1, datetime(2024, 12, 13, 0, 0), datetime(2024, 12, 14, 0, 0)) == []

def search_in_list_end_date(list,end_obj):
    '''
    :param list: [] array of Packet
    :param end_obj: datetime object
    :return results: [] array of Packet
    description:finds the list of offers with the end_date=end_obj
    '''
    results = []
    for i in list:
        if check_end_date(i,end_obj):
            results.append(i)
    return results

def search_in_list_end_date_tester():
    assert search_in_list_end_date([], datetime(2023, 12, 14, 0, 0)) == []
    database1 = [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11)]
    assert search_in_list_end_date(database1, datetime(2023, 12, 14, 0, 0)) ==[database1[0]]
    assert search_in_list_end_date(database1, datetime(2023, 12, 13, 0, 0)) == []
    database1.append(Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 15, 0, 0), 'Brasov', 90, 13))
    assert search_in_list_end_date(database1, datetime(2023, 12, 14, 0, 0)) == [database1[0]]
    assert search_in_list_end_date(database1, datetime(2023, 12, 13, 0, 0)) == []

def delete_price(list0,price_obj):
    '''
    :param list0: [] array of Packet
    :param price_obj: integer
    :return:  [] array of Packet
    :description: deletes the packets with a price bigger than a given value
    '''
    deleted = 0
    l = len(list0)
    i = 0
    try:
        while i < l:
            if check_price(list0[i], price_obj)==0:
                #print(i, ' ', list0[i])
                list0.pop(i)
                deleted += 1
                l -= 1
            else:
                i += 1
    except Exception as error:
        print(error)
    #print(list0)
    return deleted

def delete_price_tester():
    assert delete_price([], 15) == 0
    database1 = [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11)]
    assert delete_price(database1, 100) == 0
    assert delete_price(database1, 50) == 1
    database1.append(Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11))
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 15, 0, 0), 'London', 75, 13))
    assert delete_price(database1, 80) == 1
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 15, 0, 0), 'London', 120, 14))
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'London', 175, 15))
    assert delete_price(database1, 50) == 3

def delete_destination(list0,destination_obj):
    '''
    :param list0: [] array of Packets
    :param destination_obj: string
    :return:  [] array of Packet
    :description: deletes the packets with a given destination
    '''
    deleted = 0
    l=len(list0)
    i=0
    try:
        while i<l:
            if check_destination(list0[i], destination_obj):
                #print(i, ' ', list0[i])
                list0.pop(i)
                deleted += 1
                l-=1
            else:
                i+=1
    except Exception as error:
        print(error)
    #print(list0)

    return deleted

def delete_destination_tester():
    assert delete_destination([], "Brasov") == 0
    database1 = [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11)]
    assert delete_destination(database1, "London") == 0
    assert delete_destination(database1, "Brasov") == 1
    database1.append(Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11))
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'London', 75, 12))
    assert delete_destination(database1, "Brasov") == 1
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 15, 0, 0), 'London', 75, 13))
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'London', 175, 15))
    assert delete_destination(database1, "London") == 3

def delete_number_days(list0, number):
    '''
    :param list0: [] array of Packets
    :param number: integer
    :return: integer
    :description: deletes the packets with a duration less than a given number of days and returns the numbers of packets deleted
    '''
    deleted = 0
    l = len(list0)
    i = 0
    try:
        while i < l:
            if get_number_of_days(list0[i])<number:
                #print(i, ' ', list0[i])
                list0.pop(i)
                deleted += 1
                l -= 1
            else:
                i += 1
    except Exception as error:
        print(error)
    return deleted

def delete_number_days_tester():
    assert delete_number_days([], 23) == 0
    database1 = [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11)]
    assert delete_number_days(database1, 4) == 0
    assert delete_number_days(database1, 6) == 1
    database1.append(Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11))
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 15, 0, 0), 'London', 75, 13))
    assert delete_number_days(database1, 6) == 1
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 15, 0, 0), 'Brasov', 75, 14))
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'Brasov', 175, 15))
    assert delete_number_days(database1, 13) == 3

def count_destination(list,destination_obj):
    '''
    :param list: [] array of Packet
    :param destination_obj: string
    :return: integer
    :description: count how many objects in list have the given destination
    '''
    count = 0
    for i in list:
        if check_destination(i, destination_obj):
            count += 1
    return count

def count_destination_tester():
    assert count_destination([], "London") == 0
    database1 = [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11)]
    assert count_destination(database1, 'Brasov') == 1
    assert count_destination(database1, 'London') == 0
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'London', 75, 12))
    assert count_destination(database1, 'London') == 1
    database1.pop()
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'Brasov', 175, 13))
    assert count_destination(database1, 'Brasov') == 2
def sum_price(list, destination_obj):
    '''
    :param list: [] array of Packet
    :param destination_obj: string
    :return: integer
    :description: adds the prices of offers with a given destination
    '''
    sum0 = 0
    for i in list:
        if check_destination(i, destination_obj):
            sum0+=i.get_price()
    return sum0

def sum_price_tester():
    assert sum_price([], "London")==0
    database1 = [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'Brasov', 90, 11)]
    assert sum_price(database1, 'Brasov')==90
    assert sum_price(database1, 'London')==0
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'London', 75, 12))
    assert sum_price(database1, 'London') == 75
    database1.pop()
    database1.append(Packet(datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0), 'Brasov', 175, 13))
    assert sum_price(database1, 'Brasov') == 265

def average(sum0, number):
    '''
    :preconditie: number >0
    :param sum0: integer
    :param number: integer
    :return: float
    :description: calculates the average of number of values with a sum of sum0
    '''
    return  sum0 / number

def average_tester():
    epsilon=0.0000000000001
    assert abs(0-average(0, 5))<epsilon
    assert abs(1-average(5, 5))<epsilon
    assert abs(9.333333333333333-average(28, 3))<epsilon

def sort_results(list0):
    '''
    :param list0: Packet []
    :return: Packet []
    :description: sorts the list by the field of price
    '''
    return sorted(list0, key=lambda x: x.get_price())

def sort_results_tester():
    list1=[Packet(datetime(2023, 12, 10, 0, 0),  datetime(2023, 12, 14, 0, 0), 'London',  120, 11)]
    assert sort_results([])==[]
    assert sort_results(list1)==list1
    list1.append(Packet(datetime(2023, 12, 10, 0, 0),  datetime(2023, 12, 14, 0, 0), 'London',  90, 12))
    assert sort_results(list1)==[list1[1], list1[0]]

def search_packet_by_id(list1, id):
    '''
    :param list1: Packet[]
    :param id: integer
    :return: Packet
    :description: searches for the packet with the given id
    '''
    for i in list1:
        if i.get_id()==id:
            return i
    return None


def search_in_list_month(list1, month_obj):
    '''
       :param list: [] array of Packet
       :param month_obj: integer
       :return results: [] array of Packet
       description:finds the list of offers which do not contain days of a given month
       '''
    results = []
    for i in list1:
        if check_month(month_obj, i):
            results.append(i)
    return results

def search_in_list_month_tester():
    assert search_in_list_month([], 11)==[]
    database1=[Packet(datetime(2023, 12, 10, 0, 0),  datetime(2023, 12, 14, 0, 0), 'London',  120, 11)]
    assert search_in_list_month(database1, 12)==[]
    assert search_in_list_month(database1, 11)==database1
    database1.append(Packet(datetime(2023, 11, 10, 0, 0),  datetime(2023, 11, 14, 0, 0), 'London',  120, 13))
    assert search_in_list_month(database1, 12) == [database1[1]]
    assert search_in_list_month(database1, 11) == [database1[0]]
    database1.pop()
    database1.append(Packet(datetime(2023, 11, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'London', 120, 12))
    assert search_in_list_month(database1, 12) == []