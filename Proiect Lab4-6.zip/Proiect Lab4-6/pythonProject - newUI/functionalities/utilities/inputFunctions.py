from datetime import datetime

from functionalities.utilities.classFunctions import date_format, Packet, get_number_of_days


def read_date():
    '''
    :return: datetime object
    :description: transforms the date read in format DD/MM/YYYY to a datetime object
    '''
    result = input()
    while validate_date(result)==0:
        print("Invalid format")
        result = input()
    return datetime.strptime(result, date_format)

def validate_date(result):
    '''
    :param result: string
    :return: integer
    :description: validates the input date and checks if the format corresponds to date_format
    '''
    try:
        correct_input = datetime.strptime(result, date_format)
        return 1
    except:
        return 0

def validate_date_tester():
    assert validate_date("11/12/2023")==1
    assert validate_date("11/12/23")==0
    assert validate_date("11/2/2023")==1
    assert validate_date("11/02/2023")==1
    assert validate_date("1/02/2023")==1
    assert validate_date("01/02/2023")==1
    assert validate_date("01/13/2023") == 0
    assert validate_date("35/11/2023") == 0
    assert validate_date("Amsterdam") == 0
    assert validate_date("///") == 0
    assert validate_date("12-05-2027") == 0
    assert validate_date("13/11/2023a") == 0
    assert validate_date("13/ 11/2023") == 0

def read_destination():
    '''
    :return: string
    :description: reads a string and checks if its format is correct
    '''
    result = input()
    while validate_destination(result)==0:
        print("Invalid format")
        result = input()
    return result

def validate_destination(result):
    '''
    :param result: string
    :return: integer
    :description:
    '''
    return not any(char.isdigit() for char in result)

def validate_destination_tester():
    assert validate_destination("Monaco")==1
    assert validate_destination("monaco")==1
    assert validate_destination("monaco2")==0
    assert validate_destination("2023")==0

def read_price():
    '''
    :return: integer
    :description: reads the value for the price field and checks if the input is number
    '''
    result = input()
    while validate_price(result) == 0:
        print("Invalid format")
        result = input()
    return int(result)


def validate_price(result):
    '''
    :param result: string
    :return: integer
    :description: checks if a string can be turned into a numeric value
    '''
    try:
        correct_input = int(result)
        return 1
    except:
        return 0

def validate_price_tester():
    assert validate_price("123") == 1
    assert validate_price("123a") == 0
    assert validate_price("Montreal") == 0
    assert validate_price("123.59") == 0
    assert validate_price(" 123") == 1

def read_month():
    '''
       :return: integer
       :description: reads the value for the month field and checks if the input is a valid number
    '''
    result = input()
    while validate_month(result) == 0:
        print("Invalid format")
        result = input()
    return int(result)

def validate_month(result):
    '''
        :param result: string
        :return: integer
        :description: checks if a string can be turned into a numeric value for a month
        '''
    try:
        correct_input = int(result)
        if 1 <= correct_input <= 12:
            return 1
        else:
            return 0
    except:
        return 0

def validate_month_tester():
    assert validate_month("13")==0
    assert validate_month("11.2")==0
    assert validate_month("abc")==0
    assert validate_month("0")==0
    assert validate_month("-1")==0
    assert validate_month("6")==1

def read_id(database):
    '''
           :return: integer
           :description: reads the value for the id field and checks if id is unique
        '''
    result = input()
    while validate_id(result, database) == 0:
        print("Invalid format")
        result = input()
    return int(result)

def validate_id(result, database):
    '''
        :param database: [[], []] of Packet
        :param result: string
        :return: integer
        :description: checks if a string can be turned into a numeric value for a unique id
    '''
    try:
        correct_input = int(result)
        if check_unique_id(database, correct_input):
            return 1
        return 0
    except:
        return 0

def validate_id_tester():
    assert validate_id(12, [])==1
    assert validate_id(12, [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'London', 90, 11)])==1
    assert validate_id(11, [Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'London', 90, 11)])==0
    assert validate_id('abc', [])==0

def check_unique_id(database, candidate):
    '''
    :param database: [[], []] of Packet
    :param candidate: integer
    :return: integer
    :description: checks if the candidate id is unique
    '''
    ok = 1
    for i in database:
        if i.get_id() == candidate:
            ok = 0
    return ok

def check_unique_id_tester():
    assert check_unique_id([], 12)==1
    assert check_unique_id([Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'London', 90, 11)], 12)==1
    assert check_unique_id([Packet(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0), 'London', 90, 12)], 12)==0

def validate_second_date(result, first_date):
    '''
    :param result: datetime object
    :param first_date: datetime object
    :return: integer
    :description: checks if the second date follows the previously read date
    '''
    item = Packet(first_date, result, "", 0, 12)
    delta=get_number_of_days(item)
    if delta >= 1:
        return 1
    else:
        return 0

def validate_second_date_tester():
    assert validate_second_date(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 10, 0, 0)) ==1
    assert validate_second_date(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 11, 0, 0)) ==0
    assert validate_second_date(datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 9, 0, 0)) ==1

def read_second_date(first_date):
    '''
    :return: datetime object
    :description: transforms the date read in format DD/MM/YYYY to a datetime object
    '''
    result = input()
    while validate_date(result)==0 or validate_second_date(datetime.strptime(result, date_format), first_date)==0:
        print("Invalid format")
        result = input()
    return datetime.strptime(result, date_format)
