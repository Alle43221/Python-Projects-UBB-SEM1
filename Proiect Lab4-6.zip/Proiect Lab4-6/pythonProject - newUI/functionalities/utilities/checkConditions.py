from datetime import datetime

from functionalities.utilities.classFunctions import Packet

def check_destination(item, destination):
    '''
    :param item: Packet
    :param destination: string
    :return: integer
    :description: checks if the destination field of object item is equal with parameter destination
    '''
    if item.get_destination()==destination:
        return 1
    else:
        return 0

def check_destination_tester():
    assert check_destination(Packet(datetime(2023, 12, 9, 0, 0),  datetime(2023, 12, 11, 0, 0), 'London',  90, 12), 'London')  == 1
    assert check_destination(Packet(datetime(2023, 12, 9, 0, 0),  datetime(2023, 12, 11, 0, 0), 'London',  90, 12), 'Monaco')  == 0
def check_price(item, price):
    '''
        :param item: Packet
        :param price: int
        :return: integer
        :description: checks if the price field of object item is equal, is bigger or is smaller than parameter price,
    '''
    if item.get_price()<price:
        return 2
    elif item.get_price()==price:
        return 1
    else:
        return 0

def check_price_tester():
    assert check_price(Packet(datetime(2023, 12, 9, 0, 0),  datetime(2023, 12, 11, 0, 0), 'London',  90, 12), 100)  == 2
    assert check_price(Packet(datetime(2023, 12, 9, 0, 0),  datetime(2023, 12, 11, 0, 0), 'London',  90, 12), 50)  == 0
    assert check_price(Packet(datetime(2023, 12, 9, 0, 0),  datetime(2023, 12, 11, 0, 0), 'London',  90, 12), 90)  == 1

def check_end_date(item, end_date):
    '''
    :param item: Packet
    :param end_date: int
    :return: integer
    :description: checks if the end_date field of object item is equal to parameter end_date
    '''
    if item.get_end_date()==end_date:
        return 1
    else:
        return 0

def check_end_date_tester():
    assert check_end_date(Packet(datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 11, 0, 0), 'London', 90, 11), datetime(2023, 12, 11, 0, 0)) == 1
    assert check_end_date(Packet(datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 11, 0, 0), 'London', 90, 11), datetime(2023, 10, 11, 0, 0)) == 0

def check_interval(item, start_date, end_date):
    '''
    :param item:
    :param start_date:
    :param end_date:
    :return:
    '''
    if item.get_start_date()>=start_date and item.get_end_date()<=end_date:
        return 1
    else:
        return 0

def check_interval_tester():
    assert check_interval(Packet(datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 11, 0, 0), 'London', 90, 11),
                          datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 14, 0, 0)) == 1
    assert check_interval(Packet(datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 11, 0, 0), 'London', 90, 11),
                          datetime(2023, 12, 7, 0, 0), datetime(2023, 12, 10, 0, 0)) == 0
    assert check_interval(Packet(datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 11, 0, 0), 'London', 90, 11),
                          datetime(2023, 12, 10, 0, 0), datetime(2023, 12, 14, 0, 0)) == 0
    assert check_interval(Packet(datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 11, 0, 0), 'London', 90, 11),
                          datetime(2023, 10, 7, 0, 0), datetime(2023, 10, 10, 0, 0)) == 0
    assert check_interval(Packet(datetime(2023, 12, 9, 0, 0), datetime(2023, 12, 11, 0, 0), 'London', 90, 11),
                          datetime(2024, 10, 7, 0, 0), datetime(2024, 10, 10, 0, 0)) == 0

def check_month(month_obj, item):
    end_date=item.get_end_date()
    start_date=item.get_start_date()
    delta=end_date-start_date
    if delta.days>=345:
        return 0
    if end_date.year==start_date.year:
        if start_date.month <= month_obj <= end_date.month:
            return 0
        return 1
    else:
        if start_date.month <= month_obj:
            return 0
        if month_obj <= end_date.month:
            return 0
        return 1

def check_month_tester():
    assert check_month(11,Packet(datetime(2023, 11, 12), datetime(2023, 12, 12), "ro", 250, 11))==0
    assert check_month(10,Packet(datetime(2023, 11, 12), datetime(2023, 12, 12), "ro", 250, 11))==1
    assert check_month(7,Packet(datetime(2023, 3, 12), datetime(2023, 6, 12), "ro", 250, 11))==1
    assert check_month(12,Packet(datetime(2023, 11, 12), datetime(2023, 12, 12), "ro", 250, 11))==0
    assert check_month(12,Packet(datetime(2023, 11, 12), datetime(2024, 3, 12), "ro", 250, 11))==0
    assert check_month(2,Packet(datetime(2023, 11, 12), datetime(2024, 3, 12), "ro", 250, 11))==0
    assert check_month(4,Packet(datetime(2023, 11, 12), datetime(2024, 3, 12), "ro", 250, 11))==1
    assert check_month(10,Packet(datetime(2023, 11, 12), datetime(2024, 3, 12), "ro", 250, 11))==1
    assert check_month(10,Packet(datetime(2022, 11, 12), datetime(2024, 3, 12), "ro", 250, 11))==0
