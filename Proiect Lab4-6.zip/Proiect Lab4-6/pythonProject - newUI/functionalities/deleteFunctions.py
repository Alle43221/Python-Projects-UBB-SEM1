from functionalities.utilities.classFunctions import save_history
from functionalities.utilities.inputFunctions import read_destination, read_price
from functionalities.utilities.listOperations import delete_price, delete_destination, delete_number_days


def del_destination(database):
    '''
        :param database: [[],[]] of type array of Packet
        :return: none
        :description: deletes offers with a given destination
    '''
    print("Type the destination:")
    destination_obj=read_destination()
    save_history(database)
    print("Items deleted:", delete_destination(database[0], destination_obj))

def del_duration(database):
    '''
    :param database: [[],[]] of type array of Packet
    :return: none
    :description: deletes offers with a durations smaller than a given number of days
    '''
    print("Type the number of days:")
    days= read_price()
    save_history(database)
    print("Items deleted:", delete_number_days(database[0], days))

def del_price(database):
    '''
            :param database: [[],[]] of type array of Packet
            :return: none
            :description: deletes offers with a price bigger than a specified value
    '''
    print("Type the price:")
    price_obj=read_price()
    save_history(database)
    print("Items deleted:", delete_price(database[0], price_obj))