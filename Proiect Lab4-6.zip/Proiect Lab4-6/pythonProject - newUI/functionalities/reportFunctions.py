from functionalities.utilities.listOperations import count_destination, average, sum_price, search_in_list_interval, \
    sort_results
from functionalities.utilities.inputFunctions import read_destination, read_date, read_second_date
from userMenu.writeOptions import write_results_query

def r_destination(database):
    '''
        :param database: [[],[]] of type array of Packet
        :return: none
        :description: reports the number of offers for a given destination
    '''
    print("Type the destination:")
    destination_obj = read_destination()
    print("Number of matches: ", count_destination(database[0], destination_obj))

def r_duration(database):
    '''

    :param database: [[],[]] of type array of Packet
    :return: none
    :description: reports the number of offers with both dates in a given interval, ordered ascending by price
    '''
    print("Type the start date in format: DD/MM/YYYY")
    start_obj = read_date()
    print("Type the end date in format: DD/MM/YYYY")
    end_obj=read_second_date(start_obj)
    new_list=sort_results(search_in_list_interval(database[0], start_obj, end_obj))
    write_results_query(new_list)
def r_price_avg(database):
    '''
    :param database: [[],[]] of type array of Packet
    :return: none
    :description: reports on the average price of packet with specified destination
    '''
    print("Type the destination:")
    destination_obj = read_destination()
    print("Average price: ", average(sum_price(database[0],destination_obj), len(database[0])))