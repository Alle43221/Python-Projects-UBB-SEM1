from functionalities.utilities.inputFunctions import read_price, read_destination, read_month
from functionalities.utilities.listOperations import search_in_list_destination_price_reverse, search_in_list_month
from userMenu.writeOptions import write_results_query


def f_price_dest(database):
    '''
    :param database: [[],[]] of type array of Packet
    :return:none
    :description: filters the objects in database[0] and prints only the ones that conform to the condition
    '''
    print("Type the destination:")
    destination_obj = read_destination()
    print("Type the price:")
    price_obj = read_price()
    write_results_query(search_in_list_destination_price_reverse(database[0], destination_obj, price_obj))

def f_month(database):
    '''
    :param database: [[],[]] of type array of Packet
    :return: none
    :description: filters the offers in database[0] and prints only the ones that do not involve days in a specific month
    '''
    print("Type the month (an integer between 1 and 12):")
    month_obj=read_month()
    write_results_query(search_in_list_month(database[0], month_obj))
    