from functionalities.utilities.checkConditions import check_destination_tester, check_price_tester, \
    check_end_date_tester, check_interval_tester, check_month_tester
from functionalities.utilities.classFunctions import init_Packet_DB_tester, create_new_Package_tester, \
    get_number_of_days_tester
from functionalities.utilities.inputFunctions import validate_date_tester, validate_price_tester, \
    validate_destination_tester, validate_month_tester, validate_id_tester, validate_second_date_tester
from functionalities.utilities.listOperations import search_in_list_destination_price_tester, sort_results_tester, \
    average_tester, search_in_list_destination_price_reverse_tester, sum_price_tester, count_destination_tester, \
    delete_number_days_tester, delete_destination_tester, delete_price_tester, search_in_list_end_date_tester, \
    search_in_list_interval_tester, search_in_list_month_tester


def global_tester():
    #check functions
    check_destination_tester()
    check_price_tester()
    check_end_date_tester()
    check_interval_tester()
    check_month_tester()

    #input functions
    validate_date_tester()
    validate_destination_tester()
    validate_price_tester()
    validate_month_tester()
    validate_id_tester()
    validate_second_date_tester()

    #class functions
    init_Packet_DB_tester()
    create_new_Package_tester()
    get_number_of_days_tester()

    #list functions
    search_in_list_destination_price_tester()
    search_in_list_destination_price_reverse_tester()
    search_in_list_interval_tester()
    search_in_list_end_date_tester()
    delete_price_tester()
    delete_destination_tester()
    delete_number_days_tester()
    count_destination_tester()
    sum_price_tester()
    sort_results_tester()
    average_tester()
    search_in_list_month_tester()