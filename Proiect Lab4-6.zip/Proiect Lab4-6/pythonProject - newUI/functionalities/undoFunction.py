
def undo(database):
    print("Press 6 again to undo the last change")
    option=input()
    if option== "6":
        database[0]=database[1][-1].copy()
        database[1].pop()
        print("Database reverted to previous version.")
        print("Press 0 to view the packets.")
