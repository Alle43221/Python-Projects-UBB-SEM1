from datetime import datetime

from functionalities.utilities.classFunctions import date_format, append_to_database, create_new_Package
from functionalities.utilities.inputFunctions import validate_date, validate_destination, validate_price, validate_id
from functionalities.utilities.listOperations import delete_destination, search_in_list_destination_price_reverse, \
    search_in_list_end_date
from userMenu.writeOptions import write_results_query


def add_new(database, words):
    try:
        if validate_date(words[1])==0:
            print("Invalid command")
            return
        else:
            start_obj=datetime.strptime(words[1], date_format)

        if validate_date(words[2]) == 0:
            print("Invalid command")
            return
        else:
            end_obj = datetime.strptime(words[2], date_format)

        destination_obj = words[3]
        if validate_destination(destination_obj) == 0:
            print("Invalid command")
            return

        try:
            price_obj = int(words[4])
        except:
            print("Invalid command")
            return
        if validate_price(price_obj) == 0:
            print("Invalid command")
            return

        try:
            id_obj = int(words[5])
        except:
            print("Invalid command")
            return
        if validate_id(id_obj, database[0]) == 0:
            print("Invalid command")
            return

        append_to_database(database, create_new_Package(start_obj, end_obj, destination_obj, price_obj, id_obj))
        print("Packet added")
    except:
        print("Invalid command")

def delete_by_destination(database, words):
    try:
        destination_obj = words[1]
        if validate_destination(destination_obj) == 0:
            print("Invalid command4")
            return
        delete_destination(database[0], destination_obj)
    except:
        print("Invalid command")

def filter_by_price_and_destination(database, words, destination_obj=None, price_obj=None):
    try:
        try:
            price_obj = int(words[1])
        except:
            print("Invalid command5")
            return
        if validate_price(price_obj) == 0:
            print("Invalid command6")
            return
        destination_obj = words[2]
        if validate_destination(destination_obj) == 0:
            print("Invalid command4")
            return
        write_results_query(search_in_list_destination_price_reverse(database[0], destination_obj, price_obj))
    except:
        print("Invalid command")

def query_by_end_date(database, words):
    try:
        if validate_date(words[1]) == 0:
            print("Invalid command3")
            return
        else:
            end_obj = datetime.strptime(words[1], date_format)
        write_results_query(search_in_list_end_date(database[0], end_obj))
    except:
        print("Invalid command")