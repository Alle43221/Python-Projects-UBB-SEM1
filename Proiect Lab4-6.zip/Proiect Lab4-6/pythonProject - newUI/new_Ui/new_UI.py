from functionalities.utilities.classFunctions import init_Packet_DB
from new_Ui.new_UI_functions import add_new, delete_by_destination, filter_by_price_and_destination, query_by_end_date

def write_options():
    '''
    :return: none
    :description: prints the main menu with its 7 options
    '''
    print("Menu:")
    print("Add start_date end_date destination price id")
    print("Delete destination")
    print("Filter price destination")
    print("Query end_date")

def new_UI():
    write_options()
    database = init_Packet_DB()
    while True:
        commands=input()
        commands=commands.split(";")
        #print(commands)
        for i in commands:
            words=i.split(" ")
            match words[0]:
                case "Add":
                    add_new(database, words)
                case "Delete":
                    delete_by_destination(database, words)
                case "Filter":
                    filter_by_price_and_destination(database, words)
                case "Query":
                    query_by_end_date(database, words)
                case "End":
                    exit()
                case _:
                    print("Invalid command")

