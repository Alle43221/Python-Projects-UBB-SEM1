# Se dă o listă de numere întregi a1,...an generați toate sub-secvențele cu proprietatea că
# suma numerelor este divizibul cu N dat.

sir = [1, 2, 3, 4, 5, 6]
dimensiune = 6
'''
    [1, 2, 3]
          [3, 4, 5]
          [3, 4, 5, 6]
                   [6]
                   

Solutie candidat: 
    Se da o lista de dimensiune n L=(l0, l1, ..., l(n-1))
    candidat x=(x0, x1, ..., xk), xi ∈ L
    1<=k<=n-1
    
Conditie consistent:
    x=(x0, x1, ..., xk) e consistent daca x este sub-secventa (elementele se afla in ordinea din lista L)
    ∀ i ∈ [0,...,k] ∃ t>=0 ∈ ℕ : xi=l(i+t), x(i+1)=l(i+t+1), ... x(k)=l(k+t)
    
Conditie solutie:
    x=(x0, x1, ..., xk),  S= ∑xi cu i ∈ [0,...,k], n|S
'''

def check_solutie(sum, lungime):
    if sum % lungime == 0:
        return 1
    return 0


def generare_subsecvente_suma_n_div(lungime, sir):
    for inceput in range(0, lungime):
        solutie = []
        sum = 0
        for i in range(inceput, lungime):
            solutie.append(sir[i])
            sum += sir[i]
            if check_solutie(sum, lungime):
                print(solutie)


def generare_subsecvente_suma_n_div_recursiva(lungime, sir, solutie, sum, poz):
    if poz == -1:
        for i in range(0, lungime):
            generare_subsecvente_suma_n_div_recursiva(lungime, sir, solutie + [sir[i]], sir[i], i)
    else:
        if check_solutie(sum, lungime):
            print(solutie)
        if poz < lungime - 1:
            generare_subsecvente_suma_n_div_recursiva(lungime, sir, solutie + [sir[poz + 1]], sum + sir[poz + 1],
                                                      poz + 1)


generare_subsecvente_suma_n_div(dimensiune, sir)
generare_subsecvente_suma_n_div_recursiva(dimensiune, sir, [], 0, -1)
