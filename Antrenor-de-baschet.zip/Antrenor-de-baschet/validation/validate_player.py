from exceptions.validation_error import ValidationError


class ValidatePlayer:

    def validatePlayer(self, player):
        errors = ""

        if player.get_nume() == '':
            errors += "Name can not be empty!"

        if player.get_prenume() == '':
            errors += "Surname can not be empty!"

        try:
            inaltime = int(player.get_inaltime())
            if inaltime <= 0:
                errors += "Negative height!"
        except:
            errors += "Non-numeric height!"

        if player.get_post() not in ["Fundas", "Pivot", "Extrema"]:
            errors += "Invalid post!"

        if len(errors) != 0:
            raise ValidationError(errors)

        return True
