from domain.jucator import Jucator
from exceptions.repo_error import RepoError

class RepoPlayer:
    def __init__(self):
        self._repo = []

    def add_player(self, newPlayer):
        if newPlayer in self._repo:
            raise RepoError("Existing player!")
        else:
            self._repo.append(newPlayer)

    def modify_player(self, newPlayer, inaltime):
        if newPlayer not in self._repo:
            raise RepoError("Non-existing player!")
        else:
            for i in self._repo:
                if i == newPlayer:
                    i.set_inaltime(inaltime)
                    return

    def search_player(self, player):
        for i in self._repo:
            if i == player:
                return i
        return None

    def get_all(self):
        return self._repo

class RepoFile(RepoPlayer):
    def __init__(self, path):
        super().__init__()
        self.__path = path

    def get_from_file(self):
        with open(self.__path, "r") as f:
            self._repo.clear()
            lines = f.readlines()
            for i in lines:
                if i!="":
                    parts = i.split(',')
                    player = Jucator(parts[0], parts[1], parts[2], int(parts[3]))
                    self._repo.append(player)

    def write_to_file(self):
        with open(self.__path, "w") as f:
            for i in self._repo:
                f.write(str(i) + "\n")

    def add_player(self, newPlayer):
        self.get_from_file()
        RepoPlayer.add_player(self, newPlayer)
        self.write_to_file()

    def modify_player(self, newPlayer, inaltime):
        self.get_from_file()
        RepoPlayer.modify_player(self, newPlayer, inaltime)
        self.write_to_file()

    def get_all(self):
        self.get_from_file()
        return self._repo

    def search_player(self, player):
        self.get_from_file()
        return RepoPlayer.search_player(self, player)

