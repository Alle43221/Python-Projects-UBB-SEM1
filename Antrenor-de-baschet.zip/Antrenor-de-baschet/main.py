from bussiness.service_player import ServicePlayer
from persistency.repo_player import RepoFile
from presentation.ui import UI
from tests.tests_player import TestPlayer
from validation.validate_player import ValidatePlayer

validator=ValidatePlayer()
repo=RepoFile("persistency/players.txt")
service=ServicePlayer(validator, repo)
test=TestPlayer()

ui=UI(service)
test.run_all_tests()
ui.run()