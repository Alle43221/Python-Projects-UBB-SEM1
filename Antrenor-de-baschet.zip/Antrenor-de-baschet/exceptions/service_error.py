class ServiceError(Exception):
    pass