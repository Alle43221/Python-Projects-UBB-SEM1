import datetime
import random

from domain.jucator import Jucator
from exceptions.repo_error import RepoError


class ServicePlayer:
    def __init__(self, validator, repo):
        self.__validator=validator
        self.__repo=repo

    def add_player(self, nume, prenume, post, inaltime):
        player=Jucator(nume, prenume, post, inaltime)
        if self.__validator.validatePlayer(player):
            self.__repo.add_player(player)

    def modify_player(self, nume, prenume, inaltime):
        player = Jucator(nume, prenume, "Pivot", inaltime)
        if self.__validator.validatePlayer(player):
            self.__repo.modify_player(player, inaltime)

    def get_all_by_post(self, post):
        lista = []
        players=self.__repo.get_all()
        for i in players:
            if i.get_post() == post:
                lista.append(i)
        return lista

    def team(self):
        fundasi=self.get_all_by_post("Fundas")
        pivoti=self.get_all_by_post("Pivot")
        extreme = self.get_all_by_post("Extrema")
        fundasi.sort(reverse=True, key=lambda x:x.get_inaltime())
        pivoti.sort(reverse=True, key=lambda x:x.get_inaltime())
        extreme.sort(reverse=True, key=lambda x: x.get_inaltime())

        if len(fundasi)<2 or len(pivoti)<1 or len(extreme)<2:
            raise RepoError("Not enough players of each category to create team!")

        return [fundasi[0], fundasi[1]]+[pivoti[0]]+[extreme[0], extreme[1]]

    def import_players(self, path):
        adaugati=0
        with open(path, "r") as f:
            lines=f.readlines()
            for i in lines:
                if i:
                    parts=i.split(",")
                    parts[1]=parts[1].strip()
                    player=Jucator(parts[0], parts[1], "Extrema", 198)
                    if self.__repo.search_player(player) is not None:
                        pass
                    else:
                        player.set_inaltime(random.randint(150, 200))
                        pozitii=["Extrema", "Pivot", "Fundas"]
                        player.set_post(pozitii[random.randint(0, 2)])
                        self.__repo.add_player(player)
                        adaugati+=1
        return adaugati
