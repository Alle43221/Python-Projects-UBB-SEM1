from datetime import datetime

from bussiness.service_player import ServicePlayer
from domain.jucator import Jucator
from exceptions.validation_error import ValidationError
from persistency.repo_player import RepoPlayer, RepoFile
from validation.validate_player import ValidatePlayer


class TestPlayer:
    def __test_domain(self):
        nume="Muresanu"
        prenume="Ghita"
        post="Pivot"
        inaltime=190
        player= Jucator(nume, prenume, post, inaltime)
        assert player.get_nume()==nume
        assert player.get_prenume()==prenume
        assert player.get_post()==post
        assert player.get_inaltime()==inaltime
        post1 = "Fundas"
        inaltime1 = 187
        player1 = Jucator(nume, prenume, post1, inaltime1)
        assert player==player1

    def __test_crud(self):
        repo=RepoPlayer()
        assert len(repo.get_all())==0
        nume = "Muresanu"
        prenume = "Ghita"
        post = "Pivot"
        inaltime = 190
        player = Jucator(nume, prenume, post, inaltime)
        repo.add_player(player)
        assert len(repo.get_all()) == 1
        assert repo.search_player(player)==player
        repo.modify_player(player, 191)
        assert repo.search_player(player).get_inaltime()==191

    def __clean_file(self, path):
        with open(path, "w") as f:
            pass

    def __test_files(self):
        self.__clean_file("tests/test_players.txt")
        repo=RepoFile("tests/test_players.txt")
        assert repo.get_all()==[]
        player = Jucator("gfds", "gfds", "Fundas", 198)
        repo.add_player(player)
        assert len(repo.get_all())== 1
        assert repo.search_player(player)==player
        repo.modify_player(player, 191)
        assert repo.search_player(player).get_inaltime() == 191

    def __test_validation(self):
        validator=ValidatePlayer()
        player = Jucator("", "", "fdsa", -198)
        try:
            validator.validatePlayer(player)
            assert False
        except ValidationError as text:
            assert str(text)=="Name can not be empty!Surname can not be empty!Negative height!Invalid post!"
        player = Jucator("gvfds", "gfdsa", "Extrema", "gfds")
        try:
            validator.validatePlayer(player)
            assert False
        except ValidationError as text:
            assert str(text)=="Non-numeric height!"

    def __test_service(self):
        self.__clean_file("tests/test_players.txt")
        repo = RepoFile("tests/test_players.txt")
        validator = ValidatePlayer()
        service=ServicePlayer(validator, repo)
        service.add_player("gfds", "gfds", "Fundas", 189)
        assert len(repo.get_all())==1
        try:
            service.add_player("", "", "gfds", -189)
            assert False
        except:
            assert len(repo.get_all()) == 1
        service.modify_player("gfds", "gfds", 190)
        player=Jucator("gfds", "gfds", "Fundas", 189)
        assert repo.search_player(player).get_inaltime()==190
        service.add_player("Ionut", "Dragusin", "Fundas", 187)
        service.add_player("Tudor", "Dumitrescu", "Pivot", 200)
        try:
            service.team()
            assert False
        except:
            pass
        service.add_player("gfdfds", "gffdsdfdss", "Extrema", 187)
        service.add_player("gfdvcfdxs", "gfdfddsss", "Extrema", 200)
        assert  len(service.team())==5
        assert service.import_players("tests/import_players.txt")==4



    def run_all_tests(self):
        self.__test_domain()
        self.__test_crud()
        self.__test_files()
        self.__test_validation()
        self.__test_service()