from exceptions.repo_error import RepoError
from exceptions.service_error import ServiceError
from exceptions.ui_error import UIError
from exceptions.validation_error import ValidationError


class UI:
    def __init__(self, service):
        self.__commands={
            "add": self.add_player,
            "edit": self.edit_player,
            "team": self.generate_team,
            "import": self.import_players
        }
        self.__service=service

    def add_player(self, params):
        if len(params)!=4:
            raise UIError("Invalid number of params! Expected 4")
        else:
            try:
                a=int(params[3])
            except:
                raise UIError("Non-numeric value provided for parameter!")
            self.__service.add_player(params[0], params[1], params[2], params[3])
            print("Successfully added player!")

    def edit_player(self, params):
        if len(params) != 3:
            raise UIError("Invalid number of params! Expected 3")
        else:
            try:
                a = int(params[2])
            except:
                raise UIError("Non-numeric value provided for parameter!")
            self.__service.modify_player(params[0], params[1], params[2])
            print("Successfully modified player!")

    def generate_team(self, params):
        if len(params) != 0:
            raise UIError("Invalid number of params! Expected 0")
        else:
            team=self.__service.team()
            for i in team:
                print(i)

    def import_players(self, params):
        if len(params) != 1:
            raise UIError("Invalid number of params! Expected 1")
        else:
            adaugati = self.__service.import_players("persistency/"+params[0])
            print(f"Added {adaugati} new players!")

    def run(self):
        while(True):
            cmd=input(">>>")
            parts=cmd.split(' ')
            if parts[0]=="exit":
                exit()
            elif parts[0] in self.__commands:
                try:
                    params=parts[1:]
                    self.__commands[parts[0]](params)
                except RepoError as error:
                    print(f"repo error: {error}")
                except ServiceError as error:
                    print(f"service error: {error}")
                except UIError as error:
                    print(f"ui error: {error}")
                except ValidationError as error:
                    print(f"validation error: {error}")
                except Exception as error:
                    print(f"we have encountered an error: {error}")
            else:
                print("Invalid command!")
