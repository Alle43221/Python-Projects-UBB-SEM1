class Jucator():
    def __init__(self, nume, prenume, post,inaltime):
        self.__nume=nume
        self.__prenume=prenume
        self.__post=post
        self.__inaltime=inaltime

    def __eq__(self, other):
        return self.__nume==other.__nume and self.__prenume==other.__prenume

    def get_nume(self):
        return self.__nume

    def get_prenume(self):
        return self.__prenume

    def get_inaltime(self):
        return self.__inaltime

    def get_post(self):
        return self.__post

    def set_inaltime(self, inaltime):
        self.__inaltime=inaltime

    def set_post(self, post):
        self.__post=post

    def __str__(self):
        return f"{self.__nume},{self.__prenume},{self.__post},{self.__inaltime}"