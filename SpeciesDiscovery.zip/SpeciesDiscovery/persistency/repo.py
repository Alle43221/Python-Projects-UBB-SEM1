import datetime

from domain.species import Species


class Repo:
    def __init__(self):
        self._species=[]

    def get_all(self):
        return self._species

class RepoFile(Repo):
    def __init__(self, path):
        self.repo=Repo()
        Repo.__init__(self)
        self.__path=path

    def get_all(self):
        self.__read_from_file()
        return self.repo._species

    def __read_from_file(self):
        self.repo._species.clear()
        with open(self.__path, "r") as f:
            lines=f.readlines()
            for i in lines:
                if(i!=''):
                    parts=i.split(',')
                    id=int(parts[0])
                    nume=parts[1]
                    date=parts[2].split('/')
                    day=int(date[0])
                    month=int(date[1])
                    year=int(date[2])
                    realdate=datetime.datetime(year,month, day)
                    locatie=parts[3]
                    tip=parts[4]
                    lifespan=int(parts[5])
                    newspecies=Species(id, nume, realdate, locatie, tip, lifespan)
                    self.repo._species.append(newspecies)
