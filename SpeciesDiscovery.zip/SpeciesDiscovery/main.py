from business.service import Service
from persistency.repo import RepoFile
from tests .tests import Tests
from ui.ui import UI
from validator.validator import Validator

repo=RepoFile("./persistency/species.txt")

teste=Tests()
validator=Validator()
service=Service(repo, validator)
teste.run_all_tests()
ui=UI(service)

ui.run()