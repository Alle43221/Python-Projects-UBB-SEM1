import datetime

from domain.species import Dto


class Service:
    def __init__(self, repo, validator):
        self.__repo=repo
        self.__validator=validator

    def afis(self, day, month, year):
        self.__validator.validate_date(day, month, year)
        date1=datetime.datetime(year, month, day)
        lista=self.__repo.get_all()
        lista1=[]
        for i in lista:
            if i.get_data() < date1:
                lista1.append(i)
        return lista1

    def static(self):
        lista = self.__repo.get_all()
        dic=[]
        for i in lista:
            if i.get_tip() not in dic:
                dic[i.get_tip()]=Dto(i.get_lifespan(), i.get_id(), i.get_data())
            else:
                dic[i.get_tip()].set_cate(dic[i.get_tip()].get_cate()+1)
                dic[i.get_tip()].set_lifespan(dic[i.get_tip()].get_lifespan() + i.get_lifespan())
                if dic[i.get_tip()].get_data()<i.get_data():
                    dic[i.get_tip()].set_data(i.get_data())
                    dic[i.get_tip()].set_id(i.get_id())

        return dic
