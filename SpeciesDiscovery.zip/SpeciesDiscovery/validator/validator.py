from exceptions.validate_error import ValidationError


class Validator:
    def validate_date(self, day, month, year):
        days=[0,31, 0, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        errors=""
        if(year<0):
            errors+='invalid year '
        if month<1 or month>12:
            errors += 'invalid month '
        if day<1 or day > days[month]:
            errors+='invalid day '
        if month==2 and day==29:
            if year%4!=0 or year%100==0:
                errors += 'invalid day '
        if len(errors):
            raise ValidationError("invalid date")