from exceptions.ui_error import UIError
from exceptions.validate_error import ValidationError


class UI:
    def __init__(self, service):
        self.__comenzi={
            "raport":self.__raport,
            "statistici":self.__statistici
        }
        self.__service=service

    def __statistici(self, params):
        if len(params)!=0:
            raise UIError("Invalid number of parameters")
        else:
            list1=self.__service.static()
            for i in list1:
                print(i)
    def __raport(self, params):
        if len(params)!=1:
            raise UIError("Invalid number of parameters")
        else:
            try:
                parts=params[0].split('/')
                day=int(parts[0])
                month=int(parts[1])
                year=int(parts[2])
                list1=self.__service.afis(day, month, year)
                for i in list1:
                    print(i)
            except:
                raise UIError("Invalid date format")

    def run(self):
        while(True):
            comanda=input(">>>")
            parts=comanda.split("-")
            name=parts[0]
            params=parts[1:]
            if name in self.__comenzi:
                try:
                    self.__comenzi[name](params)
                except ValidationError as ex:
                    print(f"validation error: {ex}")
                except UIError as ex:
                    print(f"ui error: {ex}")
                except Exception as ex:
                    print(ex)
            else:
                print("Comanda invalida!")