class Species:
    def __init__(self, id1, nume, data, locatie, tip, lifespan):
        self.__id=id1
        self.__nume=nume
        self.__data=data
        self.__locatie=locatie
        self.__tip=tip
        self.__lifespan=lifespan

    def get_id(self):
        return self.__id

    def get_nume(self):
        return self.__nume

    def get_data(self):
        return self.__data

    def get_locatie(self):
        return self.__locatie

    def get_tip(self):
        return self.__tip

    def get_lifespan(self):
        return self.__lifespan

    def __eq__(self, other):
        return self.__id==other.__id

    def __str__(self):
        return f"{self.__id},{self.__nume},{self.__data.date()},{self.__locatie},{self.__tip},{self.__lifespan}"

class Dto:
    def __init__(self, lifespan, id1, data):
        self.__cate= 1
        self.__lifespan = lifespan
        self.__id=id1
        self.__data=data

    def get_id(self):
        return self.__id

    def set_id(self, id1):
        self.__id=id1

    def set_cate(self, cate1):
        self.__cate = cate1

    def get_cate(self):
        return self.__cate

    def get_data(self):
        return self.__data

    def set_lifespan(self, lifespan):
        self.__lifespan = lifespan

    def get_lifespan(self):
        return self.__lifespan

    def set_data(self, data1):
        self.__data = data1