class Tests:
    def run_all_tests(self):
        pass