import datetime

from domain.tractor import Tractor
from exceptions.RepoException import RepoException


class RepoTractoare:
    def __init__(self):
        self._repo=[]
        self._backup=[]

    def add_tractor(self, tractor):
        '''
        functie adaugare tractor
        :param tractor: object Tractor
        :return: none
        :exceptie: exista tractor
        '''
        for i in self._repo:
            if i==tractor:
                raise RepoException("Existing ID!")
        self._backup = self._repo[:]
        self._repo.append(tractor)

    def delete_tractor(self, tractor):
        '''
        functie stergere tractor
        :param tractor: object Tractor
        :return: none
        :exceptie: nu exista tractor
        '''
        for i in self._repo:
            if i == tractor:
                self._backup = self._repo[:]
                self._repo.remove(tractor)
                return
        raise RepoException("Non-Existing ID!")

    def cautare_tractor(self, tractor):
        '''
        cauta tractor
        :param tractor: object Tractor
        :return: object Tractor
        :exceptie: nu exista tractor
        '''
        for i in self._repo:
            if i==tractor:
                return i
        raise RepoException("Non-Existing ID!")

    def get_all(self):
        '''
        functie pentru toate tractoarele
        :return: lista de obiecte Tractor
        '''
        return self._repo

    def set_repo(self):
        '''
        restore history
        :return: none
        '''
        if self._backup:
            self._repo=self._backup[:]

class RepoFisier(RepoTractoare):
    def __init__(self, path):
        super().__init__()
        self.__path=path

    def fetch_from_file(self):
        '''
        citeste toate tractoarele din fisier
        :return: none
        '''
        with open(self.__path, "r") as f:
            lines=f.readlines()
            self._repo.clear()
            for i in lines:
                if i!="":
                    i=i.strip()
                    parts=i.split(",")
                    tractor=Tractor(int(parts[0]), parts[1], int(parts[2]), parts[3],datetime.datetime.strptime(parts[4], "%d-%m-%Y"))
                    self._repo.append(tractor)

    def write_to_file(self):
        '''
        scrie toate tractoarele in fisier
        :return: none
        '''
        with open(self.__path, "w") as f:
            for i in self._repo:
                f.write(str(i)+"\n")

    def add_tractor(self, tractor):
        '''
            functie adaugare tractor
            :param tractor: object Tractor
            :return: none
            '''
        self.fetch_from_file()
        RepoTractoare.add_tractor(self,tractor)
        self.write_to_file()

    def delete_tractor(self, tractor):
        '''
                functie stergere tractor
                :param tractor: object Tractor
                :return: none
                '''
        self.fetch_from_file()
        RepoTractoare.delete_tractor(self, tractor)
        self.write_to_file()

    def get_all(self):
        '''
        functie pentru toate tractoarele
        :return: lista de obiecte Tractor
        '''
        self.fetch_from_file()
        return RepoTractoare.get_all(self)

    def cautare_tractor(self, tractor):
        '''
                functie cautare tractor
                :param tractor: object Tractor
                :return: object Tractor
                '''
        self.fetch_from_file()
        return RepoTractoare.cautare_tractor(self, tractor)

    def set_repo(self):
        '''
        restore history
        :return: none
        '''
        RepoTractoare.set_repo(self)
        self.write_to_file()