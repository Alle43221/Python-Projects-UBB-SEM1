from datetime import datetime

from domain.tractor import Tractor

class Service:
    def __init__(self, repo, validator):
        self.__repo=repo
        self.__validate=validator

    def adaugare(self, id, denumire, pret, model, data):
        '''
        functie de adaugare tractor nou
        :param id: integer
        :param denumire: string
        :param pret: integer
        :param model: string
        :param data: datetime obj
        :return: none
        '''
        tractor=Tractor(id, denumire, pret, model, data)
        if self.__validate.validare(tractor):
            self.__repo.add_tractor(tractor)

    def delete(self, id):
        '''
        functie de stergere a tractoarelor cu numarul id in pret
        :param id: integer
        :return: integer
        '''
        cate=0
        lista=self.__repo.get_all()
        for i in lista:
            if str(id) in str(i.get_pret()):
                tractor = Tractor(i.get_id(), "", 1, "", 12 / 12 / 2023)
                self.__repo.delete_tractor(tractor)
                cate=cate+1
        return cate

    def filter(self, text, nr):
        '''
        functie de filtrare dupa denumire si pret
        :param text: string
        :param nr: integer
        :return: lista de obiecte Tractor
        '''
        lista=self.__repo.get_all()
        rez=[]
        for i in lista:
            if text in i.get_denumire():
                if nr==-1 or nr>i.get_pret():
                    rez.append(i)
                    if i.get_data() < datetime.today():
                        i.set_denumire("*"+i.get_denumire())
        return rez

    def undo(self):
        self.__repo.set_repo()