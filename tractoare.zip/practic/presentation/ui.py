from datetime import datetime

from exceptions.RepoException import RepoException
from exceptions.ValidationException import ValidationException


class UI:
    def __init__(self, service):
        self.__comenzi={
            "add": self.add_tractor,
            "delete": self.delete_tractor,
            "filter": self.filter,
            "undo":self.undo
        }
        self.__service=service
        self.__filtru={"denumire":"", "numar":-1}

    def add_tractor(self, params):
        '''
        functie adaugare tractor
        :param params: lista parametrii
        :return: none
        :exceptii: "Parametru non-numeric furnizat sau data invalida!"
                "Numar invalid de parametrii!"
        '''
        if len(params)!=5:
            print("Numar invalid de parametrii!")
        else:
            try:
                id1=int(params[0])
                pret=int(params[2])
                data=datetime.strptime(params[4], "%d-%m-%Y")
            except:
                print("Parametru non-numeric furnizat sau data invalida!")
            data = datetime.strptime(params[4], "%d-%m-%Y")
            self.__service.adaugare(int(params[0]), params[1], int(params[2]), params[3], data)
            print("Tractor adaugat cu succes!")
            self.print_filter()
    def delete_tractor(self, params):
        '''
        functie stergere tractoare
        :param params: lista parametrii
        :return: none
        :exceptii: "Parametru non-numeric furnizat!"
                "Numar invalid de parametrii!"
        '''
        if len(params) != 1:
            print("Numar invalid de parametrii!")
        else:
            try:
                id1 = int(params[0])
            except:
                print("Parametru non-numeric furnizat!")
            id1 = int(params[0])
            print(f"Numar tractoare sterse:{self.__service.delete(id1)}")
            self.print_filter()

    def filter(self, params):
        '''
        seteaza filtrele de cautare
        :param params: lista de parametrii
        :return:none
        exceptii: "Numar invalid de parametrii!"
                "Parametru non-numeric furnizat!"
                "Parametru negativ furnizat!"
        '''
        if len(params)==0:
            print("Numar invalid de parametrii!")
        else:
            text=""
            id1=0
            if len(params)>1:
                text = params[0]
                try:
                    id1=int(params[1])
                    if(id1<0):
                        print("Parametru negativ furnizat!")
                        return
                except:
                    print("Parametru non-numeric furnizat!")
            else:
                try:
                    id1 = int(params[0])
                except:
                    print("Parametru non-numeric furnizat!")
            self.__filtru["denumire"] = text
            self.__filtru["numar"] = id1
        self.print_filter()

    def print_filter(self):
        '''
        afiseaza rezultatele filtrarii
        :return:none
        :exceptii: Niciun rezultat!
        '''
        if(self.__filtru["denumire"]=="" and self.__filtru["numar"]==-1):
            return
        rez=self.__service.filter(self.__filtru["denumire"], self.__filtru["numar"])
        name=self.__filtru["denumire"]
        id1=self.__filtru["numar"]
        print(f"Filtre aplicate: text={name}, numar={id1}")
        if len(rez)==0:
            print("Niciun rezultat")
        else:
            for i in rez:
                print(str(i))

    def undo(self, params):
        '''
        undo function for last operation
        :param params: list of params
        :return: none
        :exceptii: "Numar invalid de parametrii!"
        '''
        if len(params)>0:
            print("Numar invalid de parametrii!")
        else:
            self.__service.undo()

    def run(self):
        '''
        main function
        :return: none
        '''
        while True:
            cmd=input(">>>")
            cmd=cmd.strip()
            parts=cmd.split(" ")
            params=parts[1:]
            if parts[0] in self.__comenzi:
                try:
                    self.__comenzi[parts[0]](params)
                except RepoException as text:
                    print(f"repo exception:{text}")
                except ValidationException as text:
                    print(f"validation exception:{text}")
                except Exception as text:
                    print(f"other exception:{text}")
            elif parts[0]=="exit":
                exit()
            else:
                print("Comanda invalida!")