from exceptions.ValidationException import ValidationException

class Validation:
    def validare(self, tractor):
        '''
        functie validare tractor nou
        :param tractor: Tractor object
        :return: True
        :exceptii: tractor invalid
        '''
        errors=""
        if tractor.get_id()<0:
            errors+="Id negativ!"
        if tractor.get_pret()<0:
            errors+="Pret negativ!"
        if tractor.get_denumire()=="":
            errors+="Denumire vida!"
        if tractor.get_model()=="":
            errors+="Model vid!"
        if len(errors)>0:
            raise ValidationException(errors)
        return True