from datetime import datetime
class Tractor():
    def __init__(self, id1, denumire, pret, model, data):
        self.__id=id1
        self.__denumire=denumire
        self.__pret=pret
        self.__model=model
        self.__data=data

    def get_denumire(self):
        '''
        getter for field denumire
        :return: string
        '''
        return self.__denumire

    def get_id(self):
        '''
        getter for field id
        :return: integer
        '''
        return self.__id

    def get_pret(self):
        '''
        getter for field pret
        :return: integer
        '''
        return self.__pret

    def get_data(self):
        '''
        getter for field data
        :return: datetime object
        '''
        return self.__data

    def get_model(self):
        '''
        getter for field model
        :return: string
        '''
        return self.__model

    def set_denumire(self, nume):
        '''
        setter for field denumire
        :param nume: string
        :return: none
        '''
        self.__denumire=nume

    def __eq__(self, other):
        return self.__id == other.__id

    def __str__(self):
        format="%d-%m-%Y"
        return f"{self.__id},{self.__denumire},{self.__pret},{self.__model},{datetime.__format__(self.__data, format)}"