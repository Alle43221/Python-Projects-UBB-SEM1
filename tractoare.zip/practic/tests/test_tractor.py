from _datetime import datetime

from business.service import Service
from domain.tractor import Tractor
from exceptions.ValidationException import ValidationException
from persistency.repo_tractoare import RepoTractoare, RepoFisier
from validation.validare_tractor import Validation

class TesteTractor:

    def clean_files(self, path):
        '''
        deletes the contents of files
        :param path: string
        :return: none
        '''
        with open(path, "w") as f:
            pass
    def __test_domain(self):
        '''
        functie test pentru domeniu
        :return: none
        '''
        id=1
        denumire="JohnGreen"
        pret=1250
        model="BMW"
        data=datetime.strptime("12-10-2024", "%d-%m-%Y")
        tractor=Tractor(id, denumire, pret, model, data)
        assert tractor.get_id()==id
        assert tractor.get_pret()==pret
        assert tractor.get_model()==model
        assert tractor.get_denumire()==denumire
        assert tractor.get_data()==data
        denumire1 = "JohnRed"
        pret1 = 1236
        model1 = "Ferrari"
        data = datetime.strptime("14-10-2024", "%d-%m-%Y")
        tractor1 = Tractor(id, denumire, pret, model, data)
        assert tractor==tractor1

    def __test_validare(self):
        '''
        functie test pentru validare
        :return: none
        '''
        validator=Validation()
        id = 1
        denumire = "JohnGreen"
        pret = 1250
        model = "BMW"
        data = datetime.strptime("12-10-2024", "%d-%m-%Y")
        tractor = Tractor(id, denumire, pret, model, data)
        assert validator.validare(tractor)==True
        id = -1
        denumire = ""
        pret = -89
        model = ""
        tractor1 = Tractor(id, denumire, pret, model, data)
        try:
            validator.validare(tractor)
        except ValidationException as text:
            assert str(text)=="Id negativ!Pret negativ!Denumire vida!Model vid!"

    def __test_repo(self):
        '''
        functie test pentru repo
        :return: none
        '''
        repo=RepoTractoare()
        id = 1
        denumire = "JohnGreen"
        pret = 1250
        model = "BMW"
        data = datetime.strptime("12-10-2024", "%d-%m-%Y")
        tractor = Tractor(id, denumire, pret, model, data)
        repo.add_tractor(tractor)
        assert repo.cautare_tractor(tractor)==tractor
        try:
            repo.add_tractor(tractor)
            assert False
        except:
            pass

        repo.delete_tractor(tractor)
        try:
            repo.cautare_tractor(tractor)
            assert False
        except:
            pass

    def __test_repo_files(self):
        '''
        functie test pentru repo fisiere
        :return: none
        '''
        self.clean_files("tests/tractoare_test.txt")
        repo = RepoFisier("tests/tractoare_test.txt")
        assert repo.get_all()==[]
        id = 1
        denumire = "JohnGreen"
        pret = 1250
        model = "BMW"
        data = datetime.strptime("12-10-2024", "%d-%m-%Y")
        tractor = Tractor(id, denumire, pret, model, data)
        repo.add_tractor(tractor)
        assert len(repo.get_all())==1
        try:
            repo.add_tractor(tractor)
            assert False
        except:
            pass
        repo.delete_tractor(tractor)
        assert len(repo.get_all()) == 0
        try:
            repo.cautare_tractor(tractor)
            assert False
        except:
            pass

    def __test_service(self):
        '''
        functie test pentru service
        :return: none
        '''
        repo = RepoFisier("tests/tractoare_test.txt")
        valid=Validation()
        service=Service(repo, valid)
        id = 1
        denumire = "JohnGreen"
        pret = 1250
        model = "BMW"
        data = datetime.strptime("12-10-2024", "%d-%m-%Y")
        service.adaugare(id, denumire, pret, model, data)
        assert len(repo.get_all())==1
        try:
            service.adaugare(id, denumire, pret, model, data)
            assert False
        except:
            pass
        assert service.delete(5)==1
        assert len(repo.get_all()) == 0
        service.adaugare(id, denumire, pret, model, data)
        id=2
        denumire = "JohnRed"
        pret = 131
        service.adaugare(id, denumire, pret, model, data)
        assert len(service.filter("John", 300))==1
        assert len(service.filter("John", -1))==2
        assert len(service.filter("", 300))==1
        id = 3
        service.adaugare(id, denumire, pret, model, data)
        assert len(repo.get_all()) == 3
        service.undo()
        assert len(repo.get_all()) == 2
        assert service.delete(1) == 1
        assert len(repo.get_all()) == 1
        service.undo()
        assert len(repo.get_all()) == 2

    def run_all_tests(self):
        '''
        functie rulare toate testele
        :return: none
        '''
        self.__test_domain()
        self.__test_validare()
        self.__test_repo()
        self.__test_repo_files()
        self.__test_service()