from datetime import datetime

from business.service import Service
from persistency.repo_tractoare import RepoFisier
from presentation.ui import UI
from tests.test_tractor import TesteTractor
from validation.validare_tractor import Validation

teste=TesteTractor()
teste.run_all_tests()

repo=RepoFisier("persistency/tractoare.txt")
validator=Validation()

service=Service(repo, validator)

ui=UI(service)
ui.run()
