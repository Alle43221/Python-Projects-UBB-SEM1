class RepoException(Exception):
    pass