from exceptions.repo_error import RepoError
from exceptions.service_error import ServiceError
from exceptions.ui_error import UIError


class UI:
    def __init__(self, service):
        self.__comenzi={
            "filtrare":self.__filtrare,
            "vanzare":self.__vanzare
        }
        self.__service=service

    def __vanzare(self, params):
        '''
        :param params: array of parameters
        :return: none
        :descriere: realizeaza o vanzare
        '''
        if len(params) != 3:
            raise UIError("numar invalid de parametrii")
        else:
            try:
                cod = int(params[0])
                cantitate=int(params[1])
                id1=int(params[2])
                self.__service.vanzare(cod, cantitate, id1)
            except:
                raise UIError("valoare non numerica pt parametrii sau vanzare imposibila")

    def __filtrare(self, params):
        '''
        :param params: array of parameters
        :return: none
        :descriere: filtreaza materialele cu valoare stoc mai mare decat parametrul dat
        si le scrie in fisier
        '''
        if len(params)!=1:
            raise UIError("numar invalid de parametrii")
        else:
            try:
                valoare=int(params[0])
                self.__service.filtrare_pret(valoare)
            except:
                raise UIError("valoare non numerica")

    def run(self):
        '''
        :descriere: functia principala care trebuie rulata in main
        meniul de tip consola
        :return: none
        '''
        while(True):
            comanda=input(">>>")
            if comanda=="exit":
                return
            else:
                parts=comanda.split('/')
                nume=parts[0]
                params=parts[1:]
                if nume in self.__comenzi:
                    try:
                        self.__comenzi[nume](params)
                    except UIError as ex:
                        print(f"ui error: {ex}")
                    except ServiceError as ex:
                        print(f"service error: {ex}")
                    except RepoError as ex:
                        print(f"repo error: {ex}")
                else:
                    print("comanda invalida")
