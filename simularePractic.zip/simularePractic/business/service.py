from domain.material import Material
from domain.vanzare import Vanzare
from exceptions.service_error import ServiceError


class Service():
    def __init__(self, repo, path, repo_vanzari):
        self.__path = path
        self.__repo = repo
        self.__repo_vanzari = repo_vanzari

    def filtrare_pret(self, valoare):
        '''
        :param valoare: integer
        :return: none
        :description: filtreaza materialele cu valoare stoc mai mare decat parametrul dat
        si le scrie in fisier
        '''
        lista = self.__repo.get_all()
        lista1 = []
        for i in lista:
            if i.get_stoc() * i.get_pret() > valoare:
                lista1.append(i)
        with open(self.__path, "w") as f:
            for i in lista1:
                f.write(repr(i) + '\n')

    def vanzare(self, cod, cantitate, id1):
        '''
        :param cod: integer
        :param cantitate:integer
        :param id1: integer
        :return: none
        :description: realizeaza o vanzare si o scrie in fisier
        :exceptie: vanzare imposibila
        '''
        material = self.__repo.cautare(cod)
        if material.get_stoc() < cantitate:
            raise ServiceError("vanzare imposibila")
        else:
            valoare = material.get_pret() * cantitate
            valoare_noua = Material(cod, material.get_denumire(), material.get_stoc() - cantitate, material.get_pret())
            self.__repo.update(cod, valoare_noua)
            vanzare = Vanzare(material.get_denumire(), cantitate, valoare, id1)
            self.__repo_vanzari.write_to_file(vanzare)
            self.__repo.write_all_to_file()
