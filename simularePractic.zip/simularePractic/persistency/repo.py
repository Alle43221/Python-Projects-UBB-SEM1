from domain.material import Material
from exceptions.repo_error import RepoError


class RepoFile():
    def __init__(self, path):
        self.__lista_materiale = []
        self.__path = path

    def __read_all_from_file(self):
        '''
        descriere: citeste din fisier toate materialele
        :return: none
        '''
        self.__lista_materiale.clear()
        with open(self.__path, "r") as f:
            lines = f.readlines()
            for i in lines:
                if i != '':
                    parts = i.split(',')
                    cod = int(parts[0])
                    denumire = parts[1]
                    stoc = int(parts[2])
                    pret = int(parts[3])
                    material = Material(cod, denumire, stoc, pret)
                    self.__lista_materiale.append(material)

    def write_all_to_file(self):
        '''
        descriere: scrie in fisier toate materialele
        :return: none
        '''
        with open(self.__path, "w") as f:
            for i in self.__lista_materiale:
                f.write(repr(i) + '\n')

    def get_all(self):
        '''
        returneaza toate materialele din fisier
        :return: array de materiale
        '''
        self.__read_all_from_file()
        return self.__lista_materiale

    def cautare(self, cod):
        '''
        cauta dupa cod un material
        :param cod: integer
        :return: materialul gasit
        :exceptie: item inexistent
        '''
        self.__read_all_from_file()
        for i in self.__lista_materiale:
            if i.get_cod() == cod:
                return i
        raise RepoError("item inexistent")

    def update(self, cod, valoare_noua):
        '''
        :descriere: update la materialul cu codul furnizat
        :param cod: integer
        :param valoare_noua: obiect material
        :return: none
        '''
        self.__read_all_from_file()
        for i in self.__lista_materiale:
            if i.get_cod() == cod:
                i.set_stoc(valoare_noua.get_stoc())
                return
        raise RepoError("item inexistent")


class RepoFileVanzari:
    def __init__(self, path):
        self.__path = path

    def write_to_file(self, i):
        '''
        :descriere: scrie in fisier noua vanzare furnizata
        :param i: obiect de tip vanzare
        :return: none
        '''
        with open(self.__path, "a") as f:
            f.write(str(i) + '\n')
