from tests.tests import Tests
from persistency.repo import RepoFile
from business.service import Service
from presentation.ui import UI
from persistency.repo import RepoFileVanzari

repo=RepoFile("./persistency/materiale.txt")
repo_vanzari=RepoFileVanzari("./persistency/vanzari.txt")
service=Service(repo,"./persistency/materiale_filtrate.txt", repo_vanzari)

teste=Tests(repo)
teste.run_all_tests()

ui=UI(service)
ui.run()



