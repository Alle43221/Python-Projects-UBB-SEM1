class RepoError(Exception):
    pass