from business.service import Service
from domain.material import Material
from domain.vanzare import Vanzare
from persistency.repo import RepoFile, RepoFileVanzari


class Tests:
    def __init__(self, repo):
        self.__repo=repo
    def __test_repo(self):
        '''
        descriere: testare creare cu succes material
        :return: none
        '''
        cod=12
        denumire="placaj de lemn"
        stoc=100
        pret=20
        material=Material(cod, denumire, stoc, pret)
        assert cod==material.get_cod()
        assert denumire==material.get_denumire()
        assert stoc==material.get_stoc()
        assert pret==material.get_pret()

    def __test_fisier(self):
        '''
        descriere: testare lucru cu fisiere
        :return:
        '''
        repo=RepoFile("./tests/materiale_test.txt")
        list=repo.get_all()
        material=Material(13, "gard sarma" ,50,400)
        assert len(list)==2
        assert repo.cautare(13)==material
        material1 = Material(13, "gard sarma", 51, 400)
        repo.update(13, material1)
        repo.write_all_to_file()
        newobject=repo.cautare(13)
        assert newobject.get_stoc()==51

        vanzare=Vanzare("placaj", 200, 100, 2)
        repo1=RepoFileVanzari("./tests/vanzare_test.txt")
        repo1.write_to_file(vanzare)

    def run_all_tests(self):
        self.__test_repo()
        self.__test_fisier()
