class Material:
    '''
    descriere: clasa material, cu gettere pe fiecare atribut
    '''
    def __init__(self, cod, denumire, stoc, pret):
        self.__cod=cod
        self.__denumire=denumire
        self.__stoc=stoc
        self.__pret=pret

    def set_stoc(self, stoc1):
        self.__stoc=stoc1

    def get_cod(self):
        return self.__cod

    def get_denumire(self):
        return self.__denumire

    def get_stoc(self):
        return self.__stoc

    def get_pret(self):
        return self.__pret

    def __eq__(self, other):
        return self.__cod==other.__cod

    def __repr__(self):
        return (f"{self.__cod},{self.__denumire},{self.__stoc},{self.__pret}")

    def __str__(self):
        return (f"{self.__cod},{self.__denumire},{self.__stoc},{self.__pret}")