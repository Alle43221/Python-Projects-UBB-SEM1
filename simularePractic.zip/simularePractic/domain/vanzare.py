class Vanzare:
    '''
    descriere: clasa vanzare, dto folosit pentru scrierea in fisierul corespunzator
    '''
    def __init__(self, denumire, cantitate, valoare, id1):
        self.__denumire=denumire
        self.__cantitate=cantitate
        self.__valoare=valoare
        self.__id=id1

    def __eq__(self, other):
        return self.__id==other.__id

    def __str__(self):
        return f"{self.__id},{self.__denumire},{self.__cantitate},{self.__valoare}"

