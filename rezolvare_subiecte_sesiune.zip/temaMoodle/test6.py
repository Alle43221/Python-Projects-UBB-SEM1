def f(l):
    if l==None or l==[]:
        raise ValueError()
    aux=l[0]-1
    for e in l:
        if aux-e>=0:
            return False
        aux=e
    return True

def test_f():
    try:
        f()
        assert False
    except:
        pass
    try:
        f([])
        assert False
    except:
        pass
    assert f([1, 2, 3])==True
    assert f([1, 0, 3])==False
    assert f([1])==True

test_f()

def prod(l, left, right):
    if left==right:
        if left%2==0:
            return l[left]
        else: return 1
    m=(left+right)//2
    return prod(l, left, m)*prod(l, m+1, right)

print(prod([1, 2, 3, 4, 5, 6], 0, 5))