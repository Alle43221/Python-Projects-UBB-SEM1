def f2(n):
    if n<=0:
        raise ValueError()
    l=[x for x in range(n-1, -1, -1)]
    for i in range(n-1):
        l[i+1]+=l[i]
    return l[-1]

def test_f2():
    try:
        f2(-1)
        assert False
    except:
        pass
    try:
        f2(0)
        assert False
    except:
        pass
    assert f2(1)==0
    assert f2(5)==10

test_f2()

def f_negative(l, left, right):
    #print(l[left:right+1])

    if left==right:
        return (l[left]<0)
    m=(left+right)//2
    return f_negative(l, left, m)+ f_negative(l, m+1, right)

print(f_negative([-1, 2, -3, 0, -9], 0, 4))

def merge(l, left, m, right):
    a=l[left: m+1]
    b=l[m+1: right+1]
    i=0; j=0; k=left
    while i<len(a) and j<len(b):
        if a[i]<b[j]:
            l[k]=a[i]
            i=i+1
        else:
            l[k]=b[j]
            j=j+1
        k=k+1
    while i<len(a):
        l[k]=a[i]
        i=i+1
        k=k+1
    while j<len(b):
        l[k]=b[j]
        j=j+1
        k=k+1
    print(l)

def MergeSort(l, left, right):
    if left==right:
        return
    m=(left+right)//2
    MergeSort(l, left, m)
    MergeSort(l, m+1, right)
    merge(l, left, m, right)

a=[5, 9, 8, 3, 2, 1]
MergeSort(a, 0, 5)
print(a)