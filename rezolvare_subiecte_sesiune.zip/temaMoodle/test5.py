
def sublista(l):
    dp=[1]*len(l)
    next1=[-1]*len(l)
    n=len(l)
    for i in range (n-1, -1, -1):
        if l[i]%2==0:
            for j in range(i+1, n):
                if l[j]%2==0 and l[j]<=l[i]:
                    if dp[j]+1>dp[i]:
                        dp[i]=dp[j]+1
                        next1[i]=j
    mare=0; ind=0
    for i in range(n):
        if dp[i]>mare:
            mare=dp[i]
            ind=i
    lista=[]
    lista.append(l[ind])
    while next1[ind]!=-1:
        lista.append(l[next1[ind]])
        ind=next1[ind]
    return lista

print(sublista([4, 8, 3, 6, 2, 0, 1]))

def f(n):
    if n<=0: raise ValueError()
    l=[]
    while n>0:
        c=n%10
        n=n//10
        l.append(c)
    for i in range(len(l)-1): l[i+1]+=l[i]
    return l[-1]

def test_f():
    try:
        f(0)
        assert False
    except:
        pass
    try:
        f(-1)
        assert False
    except:
        pass
    assert f(3)==3
    assert f(123)==6

def cautare_pivot(l, left, right):
    a=l[left]
    i=left
    j=right
    while i<j:
        while l[j]>=a and i<j:
            j=j-1
        l[i]=l[j]
        while l[i]<a and i<j:
            i=i+1
        l[j]=l[i]
    l[i]=a
    return i
def quicksort(l, left, right):
    pivot=cautare_pivot(l, left, right)
    if pivot+1<right:
        quicksort(l, pivot+1, right)
    if pivot-1>left:
        quicksort(l, left, pivot-1)

a=[98, 8, 7, 6, 2, 0, 7, 6]
quicksort(a, 0, 7)
print(a)

def invers(l , left, right):
    if left==right:
        return [l[left]]
    if left==right-1:
       return[l[right], l[left]]
    m=(left+right)//2

    return invers(l, m+1, right) + invers(l, left, m)

print(invers(a, 0, 7))
