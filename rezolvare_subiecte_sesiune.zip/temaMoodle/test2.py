
def f(n):
    if n<0: raise ValueError()
    if n<=1: return 1
    l=[0]*(n+1)
    l[1]=1
    for i in range(2, n+1):
        l[i]=l[i-1]+l[i-2]
    return l[n]

def test_f():
    assert f(0)==1
    assert f(1)==1
    assert f(5)==5
    try:
        f(-1)
        assert False
    except:
        pass

test_f()

def max_f(l, left, right):
    if left==right:
        return l[left]
    m=(left+right)//2
    return max(max_f(l, left, m), max_f(l, m+1, right))

print(max_f([1, 0, 3, 4, 9, 5], 0, 5))

a=[1, 3, 8, 7, 5]

def selectSort(l):
    for i in range(0, len(l)-1):
        for j in range(i+1, len(l)):
            if l[i]>l[j]:
                l[i], l[j]=l[j], l[i]

selectSort(a)
print(a)