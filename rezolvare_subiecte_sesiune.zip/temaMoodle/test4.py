def f(n):
    if(n<=0): raise ValueError()
    while n>0:
        c=n%10
        n=n//10
        if(c%2==0): return True
    return False

def test_f():
    assert f(12)==True
    assert f(13)==False
    assert f(2)==True
    assert f(3)==False
    try:
        f(0)
        assert False
    except ValueError:
        pass
    try:
        f(-1)
        assert False
    except ValueError:
        pass

test_f()

def cauta_par(l, left, right):
    if(left==right):
        return (l[left]%2==0)
    m=(left+right)//2
    return cauta_par(l, left, m) or cauta_par(l, m+1, right)

print(cauta_par([0, 1, 5, 3], 0, 3))
print(cauta_par([9, 1, 5, 3], 0, 3))

def prim(n):
    if n==2: return True
    if n%2==0: return False
    if n<=1: return False
    for i in range(3, n):
        if n%i==0: return False
    return True

def lista_prim(a):
    n=len(a)
    l=[1]*n
    poz=[-1]*n
    for i in range(n-1, -1, -1):
        if prim(a[i]):
            for j in range(i+1, n):
                if(prim(a[j])):
                    if l[j]+1>l[i]:
                        l[i]=l[j]+1
                        poz[i]=j

    mare=0; ind=0; lista=[]
    for i in range(n):
        if l[i]>mare:
            mare=l[i]
            ind=i
    lista.append(a[ind])
    while poz[ind]!=-1:
        lista.append(a[poz[ind]])
        ind=poz[ind]
    return lista
print(lista_prim([1, 2, 3, 5, 8, 9, 10, 11, 7]))

def cautare_binara(l, left, right, value):
    if left==right:
        if l[left]==value:
            return left
        else: return -1
    m=(left+right)//2
    if value<l[m]:
        return cautare_binara(l, left, m-1, value)
    if value>l[m]:
        return cautare_binara(l, m+1, right, value)
    return m

print(cautare_binara([1, 4, 5, 6, 8], 0, 4, 1))
print(cautare_binara([1, 4, 5, 6, 8], 0, 4, 8))

def cautare_binara_iterativ(l, value):
    i=0; j=len(l)-1
    while i<j:
        m=(i+j)//2
        if l[m]==value:
            return m
        if l[m]<value:
            i=m+1
        if l[m]>value:
            j=m-1
    if l[i]==value:
        return i
    if l[j]==value:
        return j
    return -1

print(cautare_binara_iterativ([1, 4, 5, 6, 8], 1))
print(cautare_binara_iterativ([1, 4, 5, 6, 8], 8))