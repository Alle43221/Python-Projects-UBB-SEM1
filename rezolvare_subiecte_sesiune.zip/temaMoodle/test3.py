def insert_sort(l):
    for i in range(1, len(l)):
        a=l[i]
        ind=i-1
        while(a<l[ind] and ind>=0):
            l[ind+1]=l[ind]
            ind=ind-1
        l[ind+1]=a

a=[1, 9, 4, 5, 7, 8]
insert_sort(a)
print(a)