def bubble_sort(list1):
    n = len(list1)
    for i in range(0, n):
        swap = 0
        for j in range(0, n - i - 1):
            if list1[j] > list1[j + 1]:
                list1[j], list1[j + 1] = list1[j + 1], list1[j]
                swap=1

        if swap==0:
            break


def shell_sort(list1):
    n = len(list1)
    gap = int((n + 1) / 2)
    while gap > 0:
        i = gap
        while i < n:
            copy = list1[i]
            j = i
            while j >= gap and list1[j] < list1[j - gap]:
                list1[j] = list1[j - gap]
                j -= gap
            list1[j] = copy
            i += 1
        if gap != 1:
            gap = int((gap + 1) / 2)
        else:
            gap -= 1


list2 = [78, 89, 3, 4, 1, 2]
bubble_sort(list2)
print(list2)
